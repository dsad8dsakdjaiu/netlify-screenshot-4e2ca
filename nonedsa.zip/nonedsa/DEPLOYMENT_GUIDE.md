# Deployment Guide for Educational Use

This guide covers deployment options for the Vulnerable Notes App in educational environments including Whop courses and YouTube demonstrations.

## 🎓 Educational Deployment Options

### 1. Local Development Setup

**Best for**: Individual learning, course development, YouTube recording

```bash
# Clone and setup
git clone <repository-url>
cd vulnerable-notes-app
npm install
cd client && npm install && cd ..

# Start MongoDB
# Option A: Local MongoDB
sudo systemctl start mongod

# Option B: Docker MongoDB
docker run -d -p 27017:27017 --name mongo-vuln mongo:latest

# Start application
npm run dev & npm run client
```

**Pros**: Full control, easy debugging, no external dependencies
**Cons**: Requires local MongoDB setup

### 2. Cloud Development Environment

**Best for**: Course participants without local setup capabilities

#### Using Replit
1. Import repository to Replit
2. Configure environment variables
3. Use built-in MongoDB or connect to Atlas
4. Run with `npm run dev`

#### Using CodeSandbox
1. Import GitHub repository
2. Install dependencies automatically
3. Configure environment
4. Use embedded preview

#### Using Gitpod
1. Add `.gitpod.yml` configuration
2. Pre-install dependencies
3. Start services automatically
4. Access via web IDE

### 3. Docker Deployment

**Best for**: Consistent environment across different systems

```dockerfile
# Dockerfile
FROM node:18-alpine

WORKDIR /app

# Backend dependencies
COPY package*.json ./
RUN npm install

# Frontend dependencies and build
COPY client/package*.json ./client/
RUN cd client && npm install

# Copy source code
COPY . .

# Build frontend
RUN cd client && npm run build

EXPOSE 5000
CMD ["npm", "start"]
```

```yaml
# docker-compose.yml
version: '3.8'
services:
  app:
    build: .
    ports:
      - "5000:5000"
    environment:
      - MONGODB_URI=mongodb://mongo:27017/vulnerable_notes_db
      - NODE_ENV=development
    depends_on:
      - mongo
    volumes:
      - .:/app
      - /app/node_modules
      - /app/client/node_modules

  mongo:
    image: mongo:5.0
    ports:
      - "27017:27017"
    volumes:
      - mongo_data:/data/db

volumes:
  mongo_data:
```

## 🎬 YouTube Demo Setup

### Recording Environment
```bash
# Clean environment for recording
docker-compose down -v  # Clear all data
docker-compose up -d    # Fresh start

# Pre-populate with demo data
node scripts/populate-demo-data.js

# Ensure consistent state
npm run reset-demo      # Custom script for demo reset
```

### Demo Script Preparation
1. **Clear browser cache** and cookies
2. **Prepare demo accounts** with known credentials
3. **Test attack flows** before recording
4. **Set up screen recording** with proper resolution
5. **Prepare speaking notes** for educational commentary

### Screen Recording Tips
- **Resolution**: 1920x1080 minimum for clarity
- **Browser zoom**: 125-150% for visibility
- **Developer tools**: Open to show network requests
- **Multiple tabs**: Victim and attacker perspectives
- **Clear annotations**: Highlight vulnerable code sections

## 🏫 Whop Course Integration

### Course Structure Recommendations

#### Module 1: Understanding the Vulnerability
- **Theory**: Path traversal concepts
- **Real-world examples**: Netlify case study
- **Code review**: Vulnerable implementation

#### Module 2: Exploitation Techniques
- **Hands-on**: Crafting malicious payloads
- **Practice**: Using the demo application
- **Variations**: Different attack vectors

#### Module 3: Detection and Prevention
- **Code analysis**: Finding vulnerabilities
- **Security testing**: Automated detection
- **Mitigation**: Implementing fixes

### Student Environment Setup

#### Option A: Cloud-Based Lab
```yaml
# Student lab environment (docker-compose)
version: '3.8'
services:
  student-app:
    image: vulnerable-notes:latest
    ports:
      - "${STUDENT_PORT}:5000"
    environment:
      - MONGODB_URI=mongodb://mongo:27017/student_${STUDENT_ID}
      - STUDENT_MODE=true
    depends_on:
      - mongo

  mongo:
    image: mongo:5.0
    volumes:
      - student_data_${STUDENT_ID}:/data/db
```

#### Option B: Local Setup Instructions
Provide students with:
1. **Installation script** for dependencies
2. **Configuration template** with environment variables
3. **Troubleshooting guide** for common issues
4. **Verification checklist** to confirm setup

### Assignment Ideas

#### Basic Level
1. **Vulnerability Discovery**: Find and document the path traversal
2. **Attack Simulation**: Execute the email binding attack
3. **Impact Assessment**: Analyze potential damage

#### Intermediate Level
1. **Payload Crafting**: Create variations of the attack
2. **Evasion Techniques**: Bypass basic filters
3. **Attack Automation**: Script the attack process

#### Advanced Level
1. **Fix Implementation**: Secure the vulnerable code
2. **Security Testing**: Write test cases for vulnerabilities
3. **Advanced Exploitation**: Chain multiple vulnerabilities

## 🔒 Security Considerations for Deployment

### Network Isolation
```bash
# Create isolated network for educational use
docker network create vuln-education --subnet=172.20.0.0/16

# Run with network isolation
docker-compose --network vuln-education up
```

### Access Controls
```nginx
# Nginx configuration for restricted access
server {
    listen 80;
    server_name vuln-demo.local;
    
    # Restrict to educational networks
    allow 192.168.1.0/24;    # Local network
    allow 10.0.0.0/8;        # Private networks
    deny all;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

### Monitoring and Logging
```javascript
// Enhanced logging for educational purposes
const educationalLogger = (req, res, next) => {
  console.log(`[EDUCATION] ${new Date().toISOString()} - ${req.method} ${req.url}`);
  
  if (req.url.includes('vulnerability')) {
    console.log('[VULNERABILITY DEMO] Request detected');
  }
  
  next();
};

app.use(educationalLogger);
```

## 📊 Analytics for Course Effectiveness

### Student Progress Tracking
```javascript
// Track vulnerability discovery
app.post('/api/education/progress', (req, res) => {
  const { studentId, vulnerabilityFound, timeToDiscover } = req.body;
  
  // Log educational metrics
  console.log(`Student ${studentId} found vulnerability in ${timeToDiscover}ms`);
  
  // Store in educational database
  educationDB.logProgress(studentId, vulnerabilityFound, timeToDiscover);
});
```

### Learning Analytics Dashboard
- **Vulnerability discovery rates**
- **Common mistakes and misconceptions**
- **Time to exploitation metrics**
- **Student engagement patterns**

## 🛠️ Customization for Different Audiences

### For Beginner Developers
```javascript
// Add helpful hints and guidance
const beginnerMode = process.env.BEGINNER_MODE === 'true';

if (beginnerMode) {
  // Add extra logging and hints
  console.log('💡 HINT: Check the URL hash parameter processing');
  console.log('🔍 Look for path traversal patterns like "../"');
}
```

### For Security Professionals
```javascript
// Advanced challenge mode
const challengeMode = process.env.CHALLENGE_MODE === 'true';

if (challengeMode) {
  // Add additional vulnerabilities to discover
  // Implement WAF bypass challenges
  // Include timing attack examples
}
```

### For Bug Bounty Hunters
```javascript
// Real-world simulation mode
const realWorldMode = process.env.REAL_WORLD_MODE === 'true';

if (realWorldMode) {
  // Add realistic error handling
  // Implement rate limiting
  // Include CAPTCHA challenges
}
```

## 🎯 Platform-Specific Deployments

### Whop Course Platform
```javascript
// Integration with Whop API
const whopAuth = async (req, res, next) => {
  const token = req.headers['x-whop-token'];
  
  try {
    const user = await whop.verifyToken(token);
    req.whopUser = user;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Whop authentication required' });
  }
};

app.use('/api/course', whopAuth);
```

### YouTube Live Coding
```bash
# Live coding setup script
#!/bin/bash

# Start clean environment
docker-compose down -v
docker-compose up -d

# Wait for services
sleep 10

# Create demo accounts
curl -X POST http://localhost:5000/api/v1/user/register \
  -H "Content-Type: application/json" \
  -d '{"username":"victim","email":"victim@demo.com","password":"demo123"}'

curl -X POST http://localhost:5000/api/v1/user/register \
  -H "Content-Type: application/json" \
  -d '{"username":"attacker","email":"attacker@evil.com","password":"evil123"}'

echo "Demo environment ready for live coding!"
```

## 📋 Pre-Deployment Checklist

### Technical Requirements
- [ ] MongoDB connection tested
- [ ] All dependencies installed
- [ ] Environment variables configured
- [ ] Port availability confirmed
- [ ] Network access verified

### Educational Content
- [ ] Vulnerability explanations updated
- [ ] Demo scenarios tested
- [ ] Code comments reviewed
- [ ] Learning objectives clear
- [ ] Assessment criteria defined

### Security Measures
- [ ] Network isolation configured
- [ ] Access controls implemented
- [ ] Monitoring enabled
- [ ] Data cleanup procedures ready
- [ ] Incident response plan available

### Quality Assurance
- [ ] All attack vectors functional
- [ ] User interface responsive
- [ ] Error handling appropriate
- [ ] Performance acceptable
- [ ] Documentation complete

## 🚀 Quick Deployment Commands

### Local Development
```bash
npm run setup:local     # Install dependencies and setup
npm run demo:start      # Start demo environment
npm run demo:reset      # Reset to clean state
npm run demo:populate   # Add sample data
```

### Docker Deployment
```bash
npm run docker:build   # Build Docker images
npm run docker:start   # Start containerized environment
npm run docker:logs    # View container logs
npm run docker:clean   # Clean up containers and volumes
```

### Cloud Deployment
```bash
npm run deploy:dev     # Deploy to development environment
npm run deploy:course  # Deploy for course use
npm run deploy:demo    # Deploy for demonstration
```

---

**Note**: Always ensure proper isolation and security measures when deploying vulnerable applications for educational purposes. Monitor access and usage to prevent misuse.
