const express = require('express');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const User = require('../models/User');
const auth = require('../middleware/auth');

const router = express.Router();

// Helper function to set multiple cookies (session, preferences, analytics, marketing)
const setUserCookies = (res, user, token) => {
  const cookieOptions = {
    httpOnly: false, // VULNERABILITY: Not httpOnly for demo purposes
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    domain: process.env.COOKIE_DOMAIN || 'localhost'
  };

  // Session cookie (JWT token)
  res.cookie('session_token', token, {
    ...cookieOptions,
    httpOnly: true, // This one should be httpOnly
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  });

  // User preferences cookie
  res.cookie('user_preferences', JSON.stringify(user.preferences), {
    ...cookieOptions,
    maxAge: 30 * 24 * 60 * 60 * 1000 // 30 days
  });

  // Analytics cookie
  res.cookie('analytics_data', JSON.stringify({
    userId: user.analytics.userId,
    sessionId: uuidv4(),
    sessionCount: user.analytics.sessionCount,
    timestamp: new Date().toISOString()
  }), {
    ...cookieOptions,
    maxAge: 365 * 24 * 60 * 60 * 1000 // 1 year
  });

  // Marketing cookie
  res.cookie('marketing_prefs', JSON.stringify({
    trackingId: user.marketing.trackingId,
    acceptsEmails: user.marketing.acceptsEmails,
    adPersonalization: user.marketing.adPersonalization
  }), {
    ...cookieOptions,
    maxAge: 365 * 24 * 60 * 60 * 1000 // 1 year
  });

  console.log(`✅ Set 4 cookies for user ${user.username}: session, preferences, analytics, marketing`);
};

// User registration
router.post('/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({
      $or: [{ email: email.toLowerCase() }, { username }]
    });

    if (existingUser) {
      return res.status(400).json({
        error: 'User already exists with this email or username'
      });
    }

    // Create new user
    const user = new User({
      username,
      email: email.toLowerCase(),
      password
    });

    // Generate email verification token
    const verificationToken = user.generateEmailVerificationToken();
    await user.save();

    // Generate JWT token
    const token = jwt.sign(
      { userId: user._id, username: user.username },
      process.env.JWT_SECRET || 'weak_secret_key_for_demo_purposes',
      { expiresIn: '24h' }
    );

    // Set multiple cookies
    setUserCookies(res, user, token);

    // Mock email sending (in real app, send verification email)
    console.log(`📧 MOCK EMAIL: Verification link for ${email}:`);
    console.log(`   http://localhost:3000/email-verification#verify_token=${verificationToken}`);

    res.status(201).json({
      message: 'User registered successfully',
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        isEmailVerified: user.isEmailVerified
      },
      verificationRequired: true
    });

  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Server error during registration' });
  }
});

// User login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user
    const user = await User.findByEmail(email);
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Check password
    const isValidPassword = await user.comparePassword(password);
    if (!isValidPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Update analytics
    user.incrementSessionCount();
    await user.save();

    // Generate JWT token
    const token = jwt.sign(
      { userId: user._id, username: user.username },
      process.env.JWT_SECRET || 'weak_secret_key_for_demo_purposes',
      { expiresIn: '24h' }
    );

    // Set multiple cookies
    setUserCookies(res, user, token);

    res.json({
      message: 'Login successful',
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        isEmailVerified: user.isEmailVerified,
        preferences: user.preferences
      }
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Server error during login' });
  }
});

// Get current user profile
router.get('/profile', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        isEmailVerified: user.isEmailVerified,
        preferences: user.preferences,
        analytics: {
          sessionCount: user.analytics.sessionCount,
          lastLogin: user.analytics.lastLogin
        },
        createdAt: user.createdAt
      }
    });

  } catch (error) {
    console.error('Profile fetch error:', error);
    res.status(500).json({ error: 'Server error fetching profile' });
  }
});

// VULNERABILITY 1: Insecure email binding via query parameters (Netlify-style)
// This endpoint allows updating user email via query parameters without CSRF protection
router.put('/', async (req, res) => {
  try {
    // VULNERABILITY: Accept email updates from query parameters
    // This mimics the Netlify vulnerability where PUT /api/v1/user?email=attacker@example.com
    // would bind the attacker's email to the authenticated user's account
    const { email: queryEmail } = req.query;
    const { email: bodyEmail, preferences } = req.body;
    
    // Determine which email to use (query param takes precedence - vulnerability!)
    const newEmail = queryEmail || bodyEmail;
    
    if (queryEmail) {
      console.log(`⚠️  VULNERABILITY TRIGGERED: Email update via query parameter: ${queryEmail}`);
    }

    // Extract user ID from various sources (session, auth header, etc.)
    let userId = null;
    
    // Try to get user ID from JWT in cookies
    const sessionToken = req.cookies?.session_token;
    if (sessionToken) {
      try {
        const decoded = jwt.verify(sessionToken, process.env.JWT_SECRET || 'weak_secret_key_for_demo_purposes');
        userId = decoded.userId;
        console.log(`🔓 Found user ID from session cookie: ${userId}`);
      } catch (err) {
        console.log('Invalid session token in cookie');
      }
    }

    // Try Authorization header as fallback
    if (!userId && req.headers.authorization) {
      const token = req.headers.authorization.split(' ')[1];
      if (token) {
        try {
          const decoded = jwt.verify(token, process.env.JWT_SECRET || 'weak_secret_key_for_demo_purposes');
          userId = decoded.userId;
          console.log(`🔓 Found user ID from Authorization header: ${userId}`);
        } catch (err) {
          console.log('Invalid Authorization token');
        }
      }
    }

    if (!userId) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // VULNERABILITY: Update email without proper validation or confirmation
    if (newEmail && newEmail !== user.email) {
      console.log(`⚠️  CRITICAL VULNERABILITY: Updating email from ${user.email} to ${newEmail} without verification!`);
      user.updateEmailUnsafe(newEmail);
    }

    // Update preferences if provided
    if (preferences) {
      user.preferences = { ...user.preferences, ...preferences };
    }

    await user.save();

    // Update cookies with new data
    const token = jwt.sign(
      { userId: user._id, username: user.username },
      process.env.JWT_SECRET || 'weak_secret_key_for_demo_purposes',
      { expiresIn: '24h' }
    );
    setUserCookies(res, user, token);

    res.json({
      message: 'User updated successfully',
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        isEmailVerified: user.isEmailVerified,
        preferences: user.preferences
      },
      warning: newEmail && newEmail !== user.email ? 'Email updated without verification' : undefined
    });

  } catch (error) {
    console.error('User update error:', error);
    res.status(500).json({ error: 'Server error updating user' });
  }
});

// VULNERABILITY 2: Email verification with client-side path traversal
// This endpoint processes verification tokens that can contain path traversal
router.post('/verify-email', async (req, res) => {
  try {
    const { token } = req.body;
    
    if (!token) {
      return res.status(400).json({ error: 'Verification token required' });
    }

    console.log(`🔍 Processing verification token: ${token}`);

    // VULNERABILITY: Client-side path traversal in token processing
    // If token contains path traversal like "../user?email=attacker@example.com"
    // the client-side JavaScript will make a request to the wrong endpoint
    if (token.includes('../')) {
      console.log(`⚠️  CRITICAL VULNERABILITY: Path traversal detected in token: ${token}`);
      console.log(`⚠️  This could redirect verification to: /api/v1/${token}`);
      
      // In a real attack, the client would make a request to:
      // /api/v1/../user?email=attacker@example.com
      // which resolves to /api/v1/user?email=attacker@example.com
      
      // For demonstration, we'll show what would happen
      const pathTraversalMatch = token.match(/\.\.\/user\?email=([^&]+)/);
      if (pathTraversalMatch) {
        const attackerEmail = pathTraversalMatch[1];
        console.log(`💀 ATTACK SIMULATION: Would bind email ${attackerEmail} to current user's account`);
        
        return res.status(200).json({
          vulnerability: 'PATH_TRAVERSAL_DETECTED',
          message: 'VULNERABILITY DEMO: Path traversal in verification token',
          attackerEmail: attackerEmail,
          description: 'In a real attack, this would bind the attacker email to the victim account',
          mitigation: 'Validate and sanitize all user inputs, especially tokens and URLs'
        });
      }
    }

    // Normal verification flow
    const user = await User.findOne({ emailVerificationToken: token });
    
    if (!user) {
      return res.status(400).json({ error: 'Invalid or expired verification token' });
    }

    user.verifyEmail();
    await user.save();

    res.json({
      message: 'Email verified successfully',
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        isEmailVerified: user.isEmailVerified
      }
    });

  } catch (error) {
    console.error('Email verification error:', error);
    res.status(500).json({ error: 'Server error during email verification' });
  }
});

// Password reset request
router.post('/reset-password-request', async (req, res) => {
  try {
    const { email } = req.body;
    
    const user = await User.findByEmail(email);
    if (!user) {
      // Don't reveal if email exists or not
      return res.json({ message: 'If the email exists, a reset link has been sent' });
    }

    // Generate reset token (weak for demo)
    const resetToken = 'reset_' + Math.random().toString(36).substr(2, 15);
    user.passwordResetToken = resetToken;
    user.passwordResetExpires = new Date(Date.now() + 3600000); // 1 hour
    await user.save();

    // Mock email sending
    console.log(`📧 MOCK EMAIL: Password reset link for ${email}:`);
    console.log(`   http://localhost:3000/reset-password?token=${resetToken}`);

    res.json({ message: 'If the email exists, a reset link has been sent' });

  } catch (error) {
    console.error('Password reset request error:', error);
    res.status(500).json({ error: 'Server error processing reset request' });
  }
});

// Logout
router.post('/logout', (req, res) => {
  try {
    // Clear all cookies
    res.clearCookie('session_token');
    res.clearCookie('user_preferences');
    res.clearCookie('analytics_data');
    res.clearCookie('marketing_prefs');

    console.log('🔓 User logged out, all cookies cleared');

    res.json({ message: 'Logged out successfully' });

  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({ error: 'Server error during logout' });
  }
});

// Admin endpoint to list all users (for demo purposes)
router.get('/admin/users', async (req, res) => {
  try {
    // VULNERABILITY: No admin authentication check
    console.log('⚠️  VULNERABILITY: Admin endpoint accessible without proper authentication');
    
    const users = await User.find().select('-password -emailVerificationToken');
    
    res.json({
      users,
      warning: 'This endpoint should require admin authentication',
      vulnerability: 'Missing authorization checks'
    });

  } catch (error) {
    console.error('Admin users fetch error:', error);
    res.status(500).json({ error: 'Server error fetching users' });
  }
});

module.exports = router;
