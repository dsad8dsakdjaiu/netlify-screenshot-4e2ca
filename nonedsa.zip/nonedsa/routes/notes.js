const express = require('express');
const Note = require('../models/Note');
const auth = require('../middleware/auth');

const router = express.Router();

// Get all notes for authenticated user
router.get('/', auth, async (req, res) => {
  try {
    const { category, pinned, archived, search, limit = 50, skip = 0 } = req.query;
    
    // Build filter object
    const filters = {};
    if (category) filters.category = category;
    if (pinned !== undefined) filters.isPinned = pinned === 'true';
    if (archived !== undefined) filters.isArchived = archived === 'true';

    let notes;
    
    if (search) {
      // Search in title, content, and tags
      notes = await Note.searchNotes(req.user.userId, search)
        .limit(parseInt(limit))
        .skip(parseInt(skip))
        .populate('author', 'username');
    } else {
      // Regular filtered query
      notes = await Note.findByUser(req.user.userId, filters)
        .limit(parseInt(limit))
        .skip(parseInt(skip))
        .populate('author', 'username');
    }

    res.json({
      notes,
      count: notes.length,
      user: req.user.username
    });

  } catch (error) {
    console.error('Notes fetch error:', error);
    res.status(500).json({ error: 'Server error fetching notes' });
  }
});

// Get single note by ID
router.get('/:id', auth, async (req, res) => {
  try {
    const note = await Note.findById(req.params.id)
      .populate('author', 'username')
      .populate('sharedWith.user', 'username');

    if (!note) {
      return res.status(404).json({ error: 'Note not found' });
    }

    // Check if user has access to this note
    if (!note.hasAccess(req.user.userId)) {
      return res.status(403).json({ error: 'Access denied to this note' });
    }

    // Increment view count
    await note.incrementViewCount();

    res.json(note);

  } catch (error) {
    console.error('Note fetch error:', error);
    if (error.name === 'CastError') {
      return res.status(400).json({ error: 'Invalid note ID format' });
    }
    res.status(500).json({ error: 'Server error fetching note' });
  }
});

// Create new note
router.post('/', auth, async (req, res) => {
  try {
    const { title, content, tags, category, isPublic, format } = req.body;

    if (!title || !content) {
      return res.status(400).json({ error: 'Title and content are required' });
    }

    const note = new Note({
      title,
      content,
      author: req.user.userId,
      tags: tags || [],
      category: category || 'personal',
      isPublic: isPublic || false,
      format: format || 'plain',
      lastEditedBy: req.user.userId
    });

    await note.save();
    await note.populate('author', 'username');

    console.log(`📝 New note created: "${title}" by ${req.user.username}`);

    res.status(201).json({
      message: 'Note created successfully',
      note
    });

  } catch (error) {
    console.error('Note creation error:', error);
    res.status(500).json({ error: 'Server error creating note' });
  }
});

// Update note
router.put('/:id', auth, async (req, res) => {
  try {
    const note = await Note.findById(req.params.id);

    if (!note) {
      return res.status(404).json({ error: 'Note not found' });
    }

    // Check if user has write access
    if (!note.hasAccess(req.user.userId, 'write')) {
      return res.status(403).json({ error: 'Access denied. You need write permission for this note.' });
    }

    const { title, content, tags, category, isPublic, isPinned, format } = req.body;

    // Update fields
    if (title !== undefined) note.title = title;
    if (content !== undefined) note.content = content;
    if (tags !== undefined) note.tags = tags;
    if (category !== undefined) note.category = category;
    if (isPublic !== undefined) note.isPublic = isPublic;
    if (isPinned !== undefined) note.isPinned = isPinned;
    if (format !== undefined) note.format = format;
    
    note.lastEditedBy = req.user.userId;

    await note.save();
    await note.populate('author', 'username');

    console.log(`✏️  Note updated: "${note.title}" by ${req.user.username}`);

    res.json({
      message: 'Note updated successfully',
      note
    });

  } catch (error) {
    console.error('Note update error:', error);
    if (error.name === 'CastError') {
      return res.status(400).json({ error: 'Invalid note ID format' });
    }
    res.status(500).json({ error: 'Server error updating note' });
  }
});

// Delete note
router.delete('/:id', auth, async (req, res) => {
  try {
    const note = await Note.findById(req.params.id);

    if (!note) {
      return res.status(404).json({ error: 'Note not found' });
    }

    // Check if user is the owner (only owner can delete)
    if (note.author.toString() !== req.user.userId.toString()) {
      return res.status(403).json({ error: 'Access denied. Only the note owner can delete this note.' });
    }

    await Note.findByIdAndDelete(req.params.id);

    console.log(`🗑️  Note deleted: "${note.title}" by ${req.user.username}`);

    res.json({ message: 'Note deleted successfully' });

  } catch (error) {
    console.error('Note deletion error:', error);
    if (error.name === 'CastError') {
      return res.status(400).json({ error: 'Invalid note ID format' });
    }
    res.status(500).json({ error: 'Server error deleting note' });
  }
});

// Share note with another user
router.post('/:id/share', auth, async (req, res) => {
  try {
    const { userEmail, permission = 'read' } = req.body;

    if (!userEmail) {
      return res.status(400).json({ error: 'User email is required' });
    }

    const note = await Note.findById(req.params.id);
    if (!note) {
      return res.status(404).json({ error: 'Note not found' });
    }

    // Check if user is the owner or has admin permission
    if (!note.hasAccess(req.user.userId, 'admin') && note.author.toString() !== req.user.userId.toString()) {
      return res.status(403).json({ error: 'Access denied. You need admin permission to share this note.' });
    }

    // Find user to share with
    const User = require('../models/User');
    const targetUser = await User.findByEmail(userEmail);
    if (!targetUser) {
      return res.status(404).json({ error: 'User not found with this email' });
    }

    // Share note
    await note.shareWith(targetUser._id, permission);

    console.log(`🤝 Note "${note.title}" shared with ${userEmail} (${permission} permission)`);

    res.json({
      message: `Note shared successfully with ${userEmail}`,
      permission
    });

  } catch (error) {
    console.error('Note sharing error:', error);
    res.status(500).json({ error: 'Server error sharing note' });
  }
});

// Get notes shared with current user
router.get('/shared/with-me', auth, async (req, res) => {
  try {
    const notes = await Note.find({
      'sharedWith.user': req.user.userId
    })
    .populate('author', 'username')
    .populate('sharedWith.user', 'username')
    .sort({ updatedAt: -1 });

    res.json({
      notes,
      count: notes.length
    });

  } catch (error) {
    console.error('Shared notes fetch error:', error);
    res.status(500).json({ error: 'Server error fetching shared notes' });
  }
});

// Archive/unarchive note
router.patch('/:id/archive', auth, async (req, res) => {
  try {
    const { archived } = req.body;
    
    const note = await Note.findById(req.params.id);
    if (!note) {
      return res.status(404).json({ error: 'Note not found' });
    }

    if (!note.hasAccess(req.user.userId, 'write')) {
      return res.status(403).json({ error: 'Access denied. You need write permission for this note.' });
    }

    note.isArchived = archived !== undefined ? archived : !note.isArchived;
    await note.save();

    const action = note.isArchived ? 'archived' : 'unarchived';
    console.log(`📦 Note "${note.title}" ${action} by ${req.user.username}`);

    res.json({
      message: `Note ${action} successfully`,
      note: {
        id: note._id,
        title: note.title,
        isArchived: note.isArchived
      }
    });

  } catch (error) {
    console.error('Note archive error:', error);
    res.status(500).json({ error: 'Server error archiving note' });
  }
});

// Get note statistics for user
router.get('/stats/overview', auth, async (req, res) => {
  try {
    const userId = req.user.userId;

    const stats = await Note.aggregate([
      { $match: { author: userId } },
      {
        $group: {
          _id: null,
          totalNotes: { $sum: 1 },
          pinnedNotes: { $sum: { $cond: ['$isPinned', 1, 0] } },
          archivedNotes: { $sum: { $cond: ['$isArchived', 1, 0] } },
          publicNotes: { $sum: { $cond: ['$isPublic', 1, 0] } },
          totalViews: { $sum: '$viewCount' },
          totalEdits: { $sum: '$editCount' },
          categories: { $addToSet: '$category' }
        }
      }
    ]);

    const categoryStats = await Note.aggregate([
      { $match: { author: userId } },
      { $group: { _id: '$category', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);

    res.json({
      overview: stats[0] || {
        totalNotes: 0,
        pinnedNotes: 0,
        archivedNotes: 0,
        publicNotes: 0,
        totalViews: 0,
        totalEdits: 0,
        categories: []
      },
      categoryBreakdown: categoryStats
    });

  } catch (error) {
    console.error('Stats fetch error:', error);
    res.status(500).json({ error: 'Server error fetching statistics' });
  }
});

module.exports = router;
