#!/bin/bash

# Vulnerable Notes App Setup Script
# Educational security demonstration platform

set -e

echo "🚨 Setting up Vulnerable Notes App - Educational Security Demo"
echo "⚠️  WARNING: This application contains deliberate vulnerabilities!"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check prerequisites
print_status "Checking prerequisites..."

# Check Node.js
if ! command -v node &> /dev/null; then
    print_error "Node.js is not installed. Please install Node.js 16+ and try again."
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 16 ]; then
    print_error "Node.js version 16+ required. Current version: $(node -v)"
    exit 1
fi
print_success "Node.js $(node -v) found"

# Check npm
if ! command -v npm &> /dev/null; then
    print_error "npm is not installed. Please install npm and try again."
    exit 1
fi
print_success "npm $(npm -v) found"

# Check MongoDB
print_status "Checking MongoDB..."
if command -v mongod &> /dev/null; then
    print_success "MongoDB found locally"
    MONGODB_LOCAL=true
elif command -v docker &> /dev/null; then
    print_warning "MongoDB not found locally, but Docker is available"
    print_status "Will use Docker MongoDB container"
    MONGODB_LOCAL=false
else
    print_warning "MongoDB not found. You'll need to:"
    echo "  1. Install MongoDB locally, or"
    echo "  2. Install Docker for containerized MongoDB, or"
    echo "  3. Use MongoDB Atlas (cloud)"
fi

# Install backend dependencies
print_status "Installing backend dependencies..."
if npm install; then
    print_success "Backend dependencies installed"
else
    print_error "Failed to install backend dependencies"
    exit 1
fi

# Install frontend dependencies
print_status "Installing frontend dependencies..."
cd client
if npm install; then
    print_success "Frontend dependencies installed"
else
    print_error "Failed to install frontend dependencies"
    exit 1
fi
cd ..

# Setup environment file
print_status "Setting up environment configuration..."
if [ ! -f .env ]; then
    cp env.example .env
    print_success "Environment file created from template"
    print_warning "Please review and update .env file as needed"
else
    print_warning ".env file already exists"
fi

# Setup MongoDB
if [ "$MONGODB_LOCAL" = true ]; then
    print_status "Starting local MongoDB..."
    if sudo systemctl start mongod 2>/dev/null || brew services start mongodb-community 2>/dev/null; then
        print_success "MongoDB started"
    else
        print_warning "Could not start MongoDB automatically. Please start it manually."
    fi
elif command -v docker &> /dev/null; then
    print_status "Setting up MongoDB with Docker..."
    if docker run -d --name mongo-vuln -p 27017:27017 mongo:5.0 2>/dev/null; then
        print_success "MongoDB container started"
    else
        print_warning "MongoDB container might already be running"
    fi
fi

# Create directories
print_status "Creating necessary directories..."
mkdir -p logs
mkdir -p uploads
print_success "Directories created"

# Setup git hooks (if in git repo)
if [ -d .git ]; then
    print_status "Setting up git hooks for security..."
    cat > .git/hooks/pre-commit << 'EOF'
#!/bin/bash
echo "⚠️  WARNING: You are committing a vulnerable application!"
echo "⚠️  Ensure this is for educational purposes only."
echo "⚠️  DO NOT deploy to production environments!"
EOF
    chmod +x .git/hooks/pre-commit
    print_success "Git security hooks installed"
fi

# Final setup verification
print_status "Verifying setup..."

# Test backend
print_status "Testing backend setup..."
timeout 10s npm run dev > /dev/null 2>&1 &
SERVER_PID=$!
sleep 5
if kill -0 $SERVER_PID 2>/dev/null; then
    kill $SERVER_PID
    print_success "Backend server test passed"
else
    print_warning "Backend server test failed - check MongoDB connection"
fi

# Test frontend build
print_status "Testing frontend build..."
cd client
if npm run build > /dev/null 2>&1; then
    print_success "Frontend build test passed"
    rm -rf build  # Clean up test build
else
    print_warning "Frontend build test failed"
fi
cd ..

echo ""
echo "=========================================="
print_success "Setup completed successfully!"
echo "=========================================="
echo ""
print_warning "IMPORTANT SECURITY REMINDERS:"
echo "• This application contains DELIBERATE vulnerabilities"
echo "• Only use for educational purposes"
echo "• DO NOT deploy to production environments"
echo "• DO NOT use with real user data"
echo ""
echo "To start the application:"
echo "  1. Terminal 1: npm run dev"
echo "  2. Terminal 2: npm run client"
echo "  3. Open: http://localhost:3000"
echo ""
echo "Educational resources:"
echo "  • README.md - Complete documentation"
echo "  • ATTACK_DEMO.md - Attack demonstration guide"
echo "  • DEPLOYMENT_GUIDE.md - Course deployment instructions"
echo ""
print_status "Happy learning! 🎓"
