import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Cookies from 'js-cookie';

// Components
import Navigation from './components/Navigation';
import Login from './components/Login';
import Register from './components/Register';
import Dashboard from './components/Dashboard';
import Notes from './components/Notes';
import NoteEditor from './components/NoteEditor';
import Profile from './components/Profile';
import EmailVerification from './components/EmailVerification';
import VulnerabilityDemo from './components/VulnerabilityDemo';

// Services
import { getCurrentUser } from './services/api';

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [authChecked, setAuthChecked] = useState(false);

  // Check authentication status on app load
  useEffect(() => {
    checkAuthStatus();
  }, []);

  const checkAuthStatus = async () => {
    try {
      // Check if session token exists
      const sessionToken = Cookies.get('session_token');
      
      if (sessionToken) {
        console.log('🔍 Session token found, verifying with server...');
        const userData = await getCurrentUser();
        setUser(userData.user);
        console.log('✅ User authenticated:', userData.user.username);
      } else {
        console.log('❌ No session token found');
      }
    } catch (error) {
      console.error('Authentication check failed:', error);
      // Clear any invalid tokens
      Cookies.remove('session_token');
      setUser(null);
    } finally {
      setLoading(false);
      setAuthChecked(true);
    }
  };

  const handleLogin = (userData) => {
    setUser(userData.user);
    console.log('🔐 User logged in:', userData.user.username);
  };

  const handleLogout = () => {
    setUser(null);
    // Clear all cookies
    Cookies.remove('session_token');
    Cookies.remove('user_preferences');
    Cookies.remove('analytics_data');
    Cookies.remove('marketing_prefs');
    console.log('🔓 User logged out, cookies cleared');
  };

  // Loading screen
  if (loading || !authChecked) {
    return (
      <div className=\"min-h-screen bg-gray-50 flex items-center justify-center\">
        <div className=\"text-center\">
          <div className=\"animate-spin rounded-full h-32 w-32 border-b-2 border-primary-600 mx-auto\"></div>
          <p className=\"mt-4 text-gray-600\">Loading Vulnerable Notes App...</p>
          <p className=\"mt-2 text-sm text-red-600\">⚠️ Educational Security Demo</p>
        </div>
      </div>
    );
  }

  return (
    <Router>
      <div className=\"min-h-screen bg-gray-50\">
        {/* Security Warning Banner */}
        <div className=\"bg-red-600 text-white text-center py-2 px-4 text-sm\">
          ⚠️ SECURITY WARNING: This application contains deliberate vulnerabilities for educational purposes. DO NOT use in production!
        </div>

        <Toaster
          position=\"top-right\"
          toastOptions={{
            duration: 4000,
            style: {
              background: '#363636',
              color: '#fff',
            },
            success: {
              style: {
                background: '#10B981',
              },
            },
            error: {
              style: {
                background: '#EF4444',
              },
            },
          }}
        />

        {user && <Navigation user={user} onLogout={handleLogout} />}

        <main className={user ? 'pt-16' : ''}>
          <Routes>
            {/* Public routes */}
            {!user ? (
              <>
                <Route path=\"/login\" element={<Login onLogin={handleLogin} />} />
                <Route path=\"/register\" element={<Register onLogin={handleLogin} />} />
                <Route path=\"/email-verification\" element={<EmailVerification />} />
                <Route path=\"/vulnerability-demo\" element={<VulnerabilityDemo />} />
                <Route path=\"*\" element={<Navigate to=\"/login\" replace />} />
              </>
            ) : (
              <>
                {/* Protected routes */}
                <Route path=\"/dashboard\" element={<Dashboard user={user} />} />
                <Route path=\"/notes\" element={<Notes user={user} />} />
                <Route path=\"/notes/new\" element={<NoteEditor user={user} />} />
                <Route path=\"/notes/:id\" element={<NoteEditor user={user} />} />
                <Route path=\"/profile\" element={<Profile user={user} setUser={setUser} />} />
                <Route path=\"/email-verification\" element={<EmailVerification />} />
                <Route path=\"/vulnerability-demo\" element={<VulnerabilityDemo />} />
                <Route path=\"*\" element={<Navigate to=\"/dashboard\" replace />} />
              </>
            )}
          </Routes>
        </main>

        {/* Footer with vulnerability info */}
        <footer className=\"bg-gray-800 text-white py-8 mt-16\">
          <div className=\"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8\">
            <div className=\"grid grid-cols-1 md:grid-cols-3 gap-8\">
              <div>
                <h3 className=\"text-lg font-semibold mb-4\">Vulnerable Notes App</h3>
                <p className=\"text-gray-300 text-sm\">
                  Educational security demonstration based on real vulnerability reports.
                  Built for learning about web application security.
                </p>
              </div>
              <div>
                <h3 className=\"text-lg font-semibold mb-4\">Vulnerabilities Included</h3>
                <ul className=\"text-gray-300 text-sm space-y-2\">
                  <li>• Client-side path traversal</li>
                  <li>• Insecure email binding</li>
                  <li>• Missing CSRF protection</li>
                  <li>• Information disclosure</li>
                  <li>• Weak authentication</li>
                </ul>
              </div>
              <div>
                <h3 className=\"text-lg font-semibold mb-4\">Educational Use</h3>
                <p className=\"text-gray-300 text-sm\">
                  Based on Netlify bug bounty report #3307106. 
                  Use responsibly for security education and training.
                </p>
                <div className=\"mt-4\">
                  <span className=\"inline-block bg-red-600 text-white text-xs px-2 py-1 rounded\">
                    FOR EDUCATIONAL USE ONLY
                  </span>
                </div>
              </div>
            </div>
            <div className=\"border-t border-gray-700 mt-8 pt-8 text-center text-gray-300 text-sm\">
              © 2024 Vulnerable Notes App - Educational Security Demo
            </div>
          </div>
        </footer>
      </div>
    </Router>
  );
}

export default App;
