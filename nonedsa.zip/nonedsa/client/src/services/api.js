import axios from 'axios';
import Cookies from 'js-cookie';

// Create axios instance with default config
const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || '/api/v1',
  withCredentials: true, // Enable sending cookies
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    // Get token from cookie
    const token = Cookies.get('session_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    
    console.log(`🌐 API Request: ${config.method?.toUpperCase()} ${config.url}`);
    return config;
  },
  (error) => {
    console.error('Request interceptor error:', error);
    return Promise.reject(error);
  }
);

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    console.error('API Error:', error.response?.data || error.message);
    
    // Handle authentication errors
    if (error.response?.status === 401) {
      console.log('🔒 Authentication failed, clearing tokens');
      Cookies.remove('session_token');
      // Optionally redirect to login
      if (window.location.pathname !== '/login') {
        window.location.href = '/login';
      }
    }
    
    return Promise.reject(error);
  }
);

// Auth API functions
export const authAPI = {
  register: async (userData) => {
    const response = await api.post('/user/register', userData);
    return response.data;
  },

  login: async (credentials) => {
    const response = await api.post('/user/login', credentials);
    return response.data;
  },

  logout: async () => {
    const response = await api.post('/user/logout');
    return response.data;
  },

  verifyEmail: async (token) => {
    const response = await api.post('/user/verify-email', { token });
    return response.data;
  },

  resetPasswordRequest: async (email) => {
    const response = await api.post('/user/reset-password-request', { email });
    return response.data;
  },

  // VULNERABILITY: Function that demonstrates insecure email binding
  updateUserVulnerable: async (email, preferences = {}) => {
    console.log('⚠️ VULNERABILITY: Updating user via query parameter');
    // This makes a PUT request with email in query parameter - vulnerable!
    const response = await api.put(`/user?email=${encodeURIComponent(email)}`, { preferences });
    return response.data;
  },

  updateUserSecure: async (userData) => {
    const response = await api.put('/user', userData);
    return response.data;
  }
};

// User API functions
export const getCurrentUser = async () => {
  const response = await api.get('/user/profile');
  return response.data;
};

export const updateUserProfile = async (userData) => {
  const response = await api.put('/user', userData);
  return response.data;
};

// Notes API functions
export const notesAPI = {
  // Get all notes for current user
  getNotes: async (filters = {}) => {
    const params = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined && value !== '') {
        params.append(key, value);
      }
    });
    
    const response = await api.get(`/notes?${params.toString()}`);
    return response.data;
  },

  // Get single note by ID
  getNote: async (id) => {
    const response = await api.get(`/notes/${id}`);
    return response.data;
  },

  // Create new note
  createNote: async (noteData) => {
    const response = await api.post('/notes', noteData);
    return response.data;
  },

  // Update existing note
  updateNote: async (id, noteData) => {
    const response = await api.put(`/notes/${id}`, noteData);
    return response.data;
  },

  // Delete note
  deleteNote: async (id) => {
    const response = await api.delete(`/notes/${id}`);
    return response.data;
  },

  // Share note with user
  shareNote: async (id, userEmail, permission = 'read') => {
    const response = await api.post(`/notes/${id}/share`, { userEmail, permission });
    return response.data;
  },

  // Get notes shared with current user
  getSharedNotes: async () => {
    const response = await api.get('/notes/shared/with-me');
    return response.data;
  },

  // Archive/unarchive note
  archiveNote: async (id, archived = true) => {
    const response = await api.patch(`/notes/${id}/archive`, { archived });
    return response.data;
  },

  // Get user statistics
  getStats: async () => {
    const response = await api.get('/notes/stats/overview');
    return response.data;
  }
};

// Vulnerability demonstration functions
export const vulnerabilityAPI = {
  // Demonstrate path traversal vulnerability
  demonstratePathTraversal: async (maliciousToken) => {
    console.log('⚠️ DEMONSTRATING PATH TRAVERSAL VULNERABILITY');
    try {
      const response = await api.post('/user/verify-email', { token: maliciousToken });
      return response.data;
    } catch (error) {
      return error.response?.data || { error: error.message };
    }
  },

  // Demonstrate email binding vulnerability
  demonstrateEmailBinding: async (victimToken, attackerEmail) => {
    console.log('⚠️ DEMONSTRATING EMAIL BINDING VULNERABILITY');
    try {
      // Create a temporary axios instance with the victim's token
      const victimAPI = axios.create({
        baseURL: process.env.REACT_APP_API_URL || '/api/v1',
        withCredentials: true,
        headers: {
          'Authorization': `Bearer ${victimToken}`,
          'Content-Type': 'application/json',
        },
      });

      // Make the vulnerable request
      const response = await victimAPI.put(`/user?email=${encodeURIComponent(attackerEmail)}`);
      return response.data;
    } catch (error) {
      return error.response?.data || { error: error.message };
    }
  },

  // Health check to see vulnerability status
  getVulnerabilityStatus: async () => {
    const response = await api.get('/health');
    return response.data;
  }
};

// Admin API functions (for demonstration)
export const adminAPI = {
  getAllUsers: async () => {
    const response = await api.get('/user/admin/users');
    return response.data;
  }
};

export default api;
