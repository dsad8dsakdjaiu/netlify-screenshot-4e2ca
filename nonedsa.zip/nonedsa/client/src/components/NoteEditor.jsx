import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { notesAPI } from '../services/api';
import toast from 'react-hot-toast';

const NoteEditor = ({ user }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEditing = Boolean(id);

  const [loading, setLoading] = useState(isEditing);
  const [saving, setSaving] = useState(false);
  const [note, setNote] = useState({
    title: '',
    content: '',
    tags: [],
    category: 'personal',
    isPublic: false,
    isPinned: false,
    format: 'plain'
  });
  
  const [tagInput, setTagInput] = useState('');

  useEffect(() => {
    if (isEditing) {
      loadNote();
    }
  }, [id, isEditing]);

  const loadNote = async () => {
    try {
      const noteData = await notesAPI.getNote(id);
      setNote(noteData);
    } catch (error) {
      console.error('Load note error:', error);
      toast.error('Failed to load note');
      navigate('/notes');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!note.title.trim()) {
      toast.error('Please enter a title');
      return;
    }

    if (!note.content.trim()) {
      toast.error('Please enter some content');
      return;
    }

    setSaving(true);
    
    try {
      if (isEditing) {
        await notesAPI.updateNote(id, note);
        toast.success('Note updated successfully');
      } else {
        const result = await notesAPI.createNote(note);
        toast.success('Note created successfully');
        navigate(`/notes/${result.note._id}`);
      }
    } catch (error) {
      console.error('Save note error:', error);
      toast.error('Failed to save note');
    } finally {
      setSaving(false);
    }
  };

  const handleAddTag = () => {
    const tag = tagInput.trim();
    if (tag && !note.tags.includes(tag)) {
      setNote({ ...note, tags: [...note.tags, tag] });
      setTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove) => {
    setNote({ ...note, tags: note.tags.filter(tag => tag !== tagToRemove) });
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddTag();
    }
  };

  const categories = ['personal', 'work', 'study', 'project', 'idea', 'other'];

  if (loading) {
    return (
      <div className=\"max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8\">
        <div className=\"animate-pulse\">
          <div className=\"h-8 bg-gray-300 rounded w-1/4 mb-6\"></div>
          <div className=\"h-64 bg-gray-300 rounded\"></div>
        </div>
      </div>
    );
  }

  return (
    <div className=\"max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8\">
      {/* Header */}
      <div className=\"flex items-center justify-between mb-8\">
        <div>
          <h1 className=\"text-3xl font-bold text-gray-900\">
            {isEditing ? 'Edit Note' : 'Create New Note'}
          </h1>
          <p className=\"mt-2 text-gray-600\">
            {isEditing ? 'Make changes to your note' : 'Write down your thoughts and ideas'}
          </p>
        </div>
        
        <div className=\"flex items-center space-x-4\">
          <button
            onClick={() => navigate('/notes')}
            className=\"btn-secondary\"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className=\"btn-primary flex items-center\"
          >
            {saving ? (
              <>
                <svg className=\"animate-spin -ml-1 mr-3 h-5 w-5 text-white\" xmlns=\"http://www.w3.org/2000/svg\" fill=\"none\" viewBox=\"0 0 24 24\">
                  <circle className=\"opacity-25\" cx=\"12\" cy=\"12\" r=\"10\" stroke=\"currentColor\" strokeWidth=\"4\"></circle>
                  <path className=\"opacity-75\" fill=\"currentColor\" d=\"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z\"></path>
                </svg>
                Saving...
              </>
            ) : (
              <>
                <svg className=\"h-5 w-5 mr-2\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\">
                  <path strokeLinecap=\"round\" strokeLinejoin=\"round\" strokeWidth={2} d=\"M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3-3m0 0l-3 3m3-3v12\" />
                </svg>
                {isEditing ? 'Update' : 'Save'}
              </>
            )}
          </button>
        </div>
      </div>

      <div className=\"grid grid-cols-1 lg:grid-cols-4 gap-8\">
        {/* Main Editor */}
        <div className=\"lg:col-span-3 space-y-6\">
          {/* Title */}
          <div>
            <label htmlFor=\"title\" className=\"block text-sm font-medium text-gray-700 mb-2\">
              Title *
            </label>
            <input
              type=\"text\"
              id=\"title\"
              value={note.title}
              onChange={(e) => setNote({ ...note, title: e.target.value })}
              className=\"input-field text-lg font-medium\"
              placeholder=\"Enter note title...\"
              required
            />
          </div>

          {/* Content */}
          <div>
            <label htmlFor=\"content\" className=\"block text-sm font-medium text-gray-700 mb-2\">
              Content *
            </label>
            <textarea
              id=\"content\"
              value={note.content}
              onChange={(e) => setNote({ ...note, content: e.target.value })}
              rows={20}
              className=\"input-field font-mono\"
              placeholder=\"Start writing your note...\"
              required
            />
            <p className=\"mt-2 text-sm text-gray-500\">
              {note.content.length} characters
            </p>
          </div>
        </div>

        {/* Sidebar */}
        <div className=\"space-y-6\">
          {/* Note Settings */}
          <div className=\"card p-6\">
            <h3 className=\"text-lg font-semibold text-gray-900 mb-4\">Settings</h3>
            
            <div className=\"space-y-4\">
              {/* Category */}
              <div>
                <label htmlFor=\"category\" className=\"block text-sm font-medium text-gray-700 mb-2\">
                  Category
                </label>
                <select
                  id=\"category\"
                  value={note.category}
                  onChange={(e) => setNote({ ...note, category: e.target.value })}
                  className=\"input-field\"
                >
                  {categories.map(cat => (
                    <option key={cat} value={cat} className=\"capitalize\">{cat}</option>
                  ))}
                </select>
              </div>

              {/* Format */}
              <div>
                <label htmlFor=\"format\" className=\"block text-sm font-medium text-gray-700 mb-2\">
                  Format
                </label>
                <select
                  id=\"format\"
                  value={note.format}
                  onChange={(e) => setNote({ ...note, format: e.target.value })}
                  className=\"input-field\"
                >
                  <option value=\"plain\">Plain Text</option>
                  <option value=\"markdown\">Markdown</option>
                  <option value=\"rich\">Rich Text</option>
                </select>
              </div>

              {/* Toggles */}
              <div className=\"space-y-3\">
                <label className=\"flex items-center\">
                  <input
                    type=\"checkbox\"
                    checked={note.isPinned}
                    onChange={(e) => setNote({ ...note, isPinned: e.target.checked })}
                    className=\"h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded\"
                  />
                  <span className=\"ml-2 text-sm text-gray-700\">Pin this note</span>
                </label>

                <label className=\"flex items-center\">
                  <input
                    type=\"checkbox\"
                    checked={note.isPublic}
                    onChange={(e) => setNote({ ...note, isPublic: e.target.checked })}
                    className=\"h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded\"
                  />
                  <span className=\"ml-2 text-sm text-gray-700\">Make public</span>
                </label>
              </div>
            </div>
          </div>

          {/* Tags */}
          <div className=\"card p-6\">
            <h3 className=\"text-lg font-semibold text-gray-900 mb-4\">Tags</h3>
            
            <div className=\"space-y-3\">
              {/* Add Tag */}
              <div className=\"flex space-x-2\">
                <input
                  type=\"text\"
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className=\"input-field flex-1\"
                  placeholder=\"Add tag...\"
                />
                <button
                  onClick={handleAddTag}
                  className=\"btn-secondary\"
                  disabled={!tagInput.trim()}
                >
                  Add
                </button>
              </div>

              {/* Tag List */}
              {note.tags.length > 0 && (
                <div className=\"flex flex-wrap gap-2\">
                  {note.tags.map((tag, index) => (
                    <span
                      key={index}
                      className=\"inline-flex items-center px-3 py-1 text-sm bg-blue-100 text-blue-700 rounded-full\"
                    >
                      {tag}
                      <button
                        onClick={() => handleRemoveTag(tag)}
                        className=\"ml-2 text-blue-500 hover:text-blue-700\"
                      >
                        <svg className=\"h-4 w-4\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\">
                          <path strokeLinecap=\"round\" strokeLinejoin=\"round\" strokeWidth={2} d=\"M6 18L18 6M6 6l12 12\" />
                        </svg>
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Note Info */}
          {isEditing && (
            <div className=\"card p-6\">
              <h3 className=\"text-lg font-semibold text-gray-900 mb-4\">Note Info</h3>
              
              <div className=\"space-y-3 text-sm\">
                <div className=\"flex justify-between\">
                  <span className=\"text-gray-600\">Created:</span>
                  <span className=\"font-medium\">
                    {new Date(note.createdAt).toLocaleDateString()}
                  </span>
                </div>
                <div className=\"flex justify-between\">
                  <span className=\"text-gray-600\">Updated:</span>
                  <span className=\"font-medium\">
                    {new Date(note.updatedAt).toLocaleDateString()}
                  </span>
                </div>
                <div className=\"flex justify-between\">
                  <span className=\"text-gray-600\">Version:</span>
                  <span className=\"font-medium\">v{note.version || 1}</span>
                </div>
                <div className=\"flex justify-between\">
                  <span className=\"text-gray-600\">Views:</span>
                  <span className=\"font-medium\">{note.viewCount || 0}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default NoteEditor;
