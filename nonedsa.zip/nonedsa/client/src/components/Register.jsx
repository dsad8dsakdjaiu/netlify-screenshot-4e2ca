import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import { authAPI } from '../services/api';

const Register = ({ onLogin }) => {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (formData.password !== formData.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }

    if (formData.password.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }

    setLoading(true);

    try {
      const result = await authAPI.register({
        username: formData.username,
        email: formData.email,
        password: formData.password
      });
      
      onLogin(result);
      toast.success(`Welcome ${result.user.username}! Please check your email for verification.`);
    } catch (error) {
      console.error('Registration error:', error);
      toast.error(error.response?.data?.error || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className=\"min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8\">
      <div className=\"sm:mx-auto sm:w-full sm:max-w-md\">
        <div className=\"text-center\">
          <div className=\"mx-auto h-12 w-12 bg-primary-600 rounded-lg flex items-center justify-center\">
            <svg className=\"h-8 w-8 text-white\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\">
              <path strokeLinecap=\"round\" strokeLinejoin=\"round\" strokeWidth={2} d=\"M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z\" />
            </svg>
          </div>
          <h2 className=\"mt-6 text-3xl font-extrabold text-gray-900\">
            Create your account
          </h2>
          <p className=\"mt-2 text-sm text-gray-600\">
            Join the educational security platform
          </p>
        </div>
      </div>

      <div className=\"mt-8 sm:mx-auto sm:w-full sm:max-w-md\">
        <div className=\"card px-6 py-8 sm:px-8\">
          <form onSubmit={handleSubmit} className=\"space-y-6\">
            <div>
              <label htmlFor=\"username\" className=\"block text-sm font-medium text-gray-700\">
                Username
              </label>
              <div className=\"mt-1\">
                <input
                  id=\"username\"
                  name=\"username\"
                  type=\"text\"
                  autoComplete=\"username\"
                  required
                  value={formData.username}
                  onChange={handleChange}
                  className=\"input-field\"
                  placeholder=\"Choose a username\"
                />
              </div>
            </div>

            <div>
              <label htmlFor=\"email\" className=\"block text-sm font-medium text-gray-700\">
                Email address
              </label>
              <div className=\"mt-1\">
                <input
                  id=\"email\"
                  name=\"email\"
                  type=\"email\"
                  autoComplete=\"email\"
                  required
                  value={formData.email}
                  onChange={handleChange}
                  className=\"input-field\"
                  placeholder=\"Enter your email\"
                />
              </div>
            </div>

            <div>
              <label htmlFor=\"password\" className=\"block text-sm font-medium text-gray-700\">
                Password
              </label>
              <div className=\"mt-1\">
                <input
                  id=\"password\"
                  name=\"password\"
                  type=\"password\"
                  autoComplete=\"new-password\"
                  required
                  value={formData.password}
                  onChange={handleChange}
                  className=\"input-field\"
                  placeholder=\"Create a password\"
                />
              </div>
            </div>

            <div>
              <label htmlFor=\"confirmPassword\" className=\"block text-sm font-medium text-gray-700\">
                Confirm Password
              </label>
              <div className=\"mt-1\">
                <input
                  id=\"confirmPassword\"
                  name=\"confirmPassword\"
                  type=\"password\"
                  autoComplete=\"new-password\"
                  required
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  className=\"input-field\"
                  placeholder=\"Confirm your password\"
                />
              </div>
            </div>

            <div>
              <button
                type=\"submit\"
                disabled={loading}
                className=\"btn-primary w-full flex justify-center items-center\"
              >
                {loading ? (
                  <>
                    <svg className=\"animate-spin -ml-1 mr-3 h-5 w-5 text-white\" xmlns=\"http://www.w3.org/2000/svg\" fill=\"none\" viewBox=\"0 0 24 24\">
                      <circle className=\"opacity-25\" cx=\"12\" cy=\"12\" r=\"10\" stroke=\"currentColor\" strokeWidth=\"4\"></circle>
                      <path className=\"opacity-75\" fill=\"currentColor\" d=\"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z\"></path>
                    </svg>
                    Creating account...
                  </>
                ) : (
                  'Create account'
                )}
              </button>
            </div>
          </form>

          <div className=\"mt-6 text-center\">
            <p className=\"text-sm text-gray-600\">
              Already have an account?{' '}
              <Link to=\"/login\" className=\"font-medium text-primary-600 hover:text-primary-500\">
                Sign in
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;
