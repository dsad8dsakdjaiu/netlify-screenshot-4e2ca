import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { notesAPI } from '../services/api';
import toast from 'react-hot-toast';

const Dashboard = ({ user }) => {
  const [stats, setStats] = useState(null);
  const [recentNotes, setRecentNotes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const [statsData, notesData] = await Promise.all([
        notesAPI.getStats(),
        notesAPI.getNotes({ limit: 5 })
      ]);

      setStats(statsData.overview);
      setRecentNotes(notesData.notes);
    } catch (error) {
      console.error('Dashboard load error:', error);
      toast.error('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className=\"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8\">
        <div className=\"animate-pulse\">
          <div className=\"h-8 bg-gray-300 rounded w-1/4 mb-8\"></div>
          <div className=\"grid grid-cols-1 md:grid-cols-4 gap-6 mb-8\">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className=\"h-24 bg-gray-300 rounded-lg\"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const statCards = [
    {
      title: 'Total Notes',
      value: stats?.totalNotes || 0,
      icon: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z',
      color: 'bg-blue-500'
    },
    {
      title: 'Pinned Notes',
      value: stats?.pinnedNotes || 0,
      icon: 'M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z',
      color: 'bg-yellow-500'
    },
    {
      title: 'Total Views',
      value: stats?.totalViews || 0,
      icon: 'M15 12a3 3 0 11-6 0 3 3 0 016 0z M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z',
      color: 'bg-green-500'
    },
    {
      title: 'Public Notes',
      value: stats?.publicNotes || 0,
      icon: 'M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z',
      color: 'bg-purple-500'
    }
  ];

  return (
    <div className=\"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8\">
      {/* Welcome Header */}
      <div className=\"mb-8\">
        <h1 className=\"text-3xl font-bold text-gray-900\">
          Welcome back, {user.username}!
        </h1>
        <p className=\"mt-2 text-gray-600\">
          Here's what's happening with your notes today.
        </p>
        
        {!user.isEmailVerified && (
          <div className=\"mt-4 p-4 bg-yellow-50 border-l-4 border-yellow-400\">
            <div className=\"flex\">
              <div className=\"flex-shrink-0\">
                <svg className=\"h-5 w-5 text-yellow-400\" viewBox=\"0 0 20 20\" fill=\"currentColor\">
                  <path fillRule=\"evenodd\" d=\"M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z\" clipRule=\"evenodd\" />
                </svg>
              </div>
              <div className=\"ml-3\">
                <p className=\"text-sm text-yellow-700\">
                  <strong>Email not verified:</strong> Please check your email and verify your account.
                  <Link to=\"/email-verification\" className=\"ml-2 font-medium underline hover:text-yellow-600\">
                    Verify now →
                  </Link>
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Stats Cards */}
      <div className=\"grid grid-cols-1 md:grid-cols-4 gap-6 mb-8\">
        {statCards.map((stat, index) => (
          <div key={index} className=\"card p-6\">
            <div className=\"flex items-center\">
              <div className={`p-3 rounded-lg ${stat.color}`}>
                <svg className=\"h-6 w-6 text-white\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\">
                  <path strokeLinecap=\"round\" strokeLinejoin=\"round\" strokeWidth={2} d={stat.icon} />
                </svg>
              </div>
              <div className=\"ml-4\">
                <p className=\"text-sm font-medium text-gray-600\">{stat.title}</p>
                <p className=\"text-2xl font-bold text-gray-900\">{stat.value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className=\"grid grid-cols-1 lg:grid-cols-3 gap-8\">
        {/* Recent Notes */}
        <div className=\"lg:col-span-2\">
          <div className=\"card p-6\">
            <div className=\"flex items-center justify-between mb-6\">
              <h2 className=\"text-lg font-semibold text-gray-900\">Recent Notes</h2>
              <Link
                to=\"/notes\"
                className=\"text-sm text-primary-600 hover:text-primary-500 font-medium\"
              >
                View all →
              </Link>
            </div>

            {recentNotes.length === 0 ? (
              <div className=\"text-center py-8\">
                <svg className=\"mx-auto h-12 w-12 text-gray-400\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\">
                  <path strokeLinecap=\"round\" strokeLinejoin=\"round\" strokeWidth={2} d=\"M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z\" />
                </svg>
                <h3 className=\"mt-2 text-sm font-medium text-gray-900\">No notes yet</h3>
                <p className=\"mt-1 text-sm text-gray-500\">Get started by creating your first note.</p>
                <div className=\"mt-6\">
                  <Link
                    to=\"/notes/new\"
                    className=\"btn-primary\"
                  >
                    Create Note
                  </Link>
                </div>
              </div>
            ) : (
              <div className=\"space-y-4\">
                {recentNotes.map((note) => (
                  <Link
                    key={note._id}
                    to={`/notes/${note._id}`}
                    className=\"block p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors duration-200\"
                  >
                    <div className=\"flex items-start justify-between\">
                      <div className=\"flex-1\">
                        <h3 className=\"text-sm font-medium text-gray-900\">{note.title}</h3>
                        <p className=\"mt-1 text-sm text-gray-600 line-clamp-2\">{note.excerpt}</p>
                        <div className=\"mt-2 flex items-center space-x-4 text-xs text-gray-500\">
                          <span>Updated {new Date(note.updatedAt).toLocaleDateString()}</span>
                          <span>•</span>
                          <span className=\"capitalize\">{note.category}</span>
                          {note.isPinned && (
                            <>
                              <span>•</span>
                              <span className=\"text-yellow-600\">Pinned</span>
                            </>
                          )}
                        </div>
                      </div>
                      {note.tags && note.tags.length > 0 && (
                        <div className=\"ml-4 flex flex-wrap gap-1\">
                          {note.tags.slice(0, 2).map((tag, tagIndex) => (
                            <span
                              key={tagIndex}
                              className=\"inline-block px-2 py-1 text-xs bg-gray-100 text-gray-700 rounded\"
                            >
                              {tag}
                            </span>
                          ))}
                          {note.tags.length > 2 && (
                            <span className=\"inline-block px-2 py-1 text-xs bg-gray-100 text-gray-700 rounded\">
                              +{note.tags.length - 2}
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Quick Actions Sidebar */}
        <div className=\"space-y-6\">
          {/* Create Note */}
          <div className=\"card p-6\">
            <h3 className=\"text-lg font-semibold text-gray-900 mb-4\">Quick Actions</h3>
            <div className=\"space-y-3\">
              <Link
                to=\"/notes/new\"
                className=\"btn-primary w-full flex items-center justify-center\"
              >
                <svg className=\"h-5 w-5 mr-2\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\">
                  <path strokeLinecap=\"round\" strokeLinejoin=\"round\" strokeWidth={2} d=\"M12 6v6m0 0v6m0-6h6m-6 0H6\" />
                </svg>
                New Note
              </Link>
              
              <Link
                to=\"/notes\"
                className=\"btn-secondary w-full flex items-center justify-center\"
              >
                <svg className=\"h-5 w-5 mr-2\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\">
                  <path strokeLinecap=\"round\" strokeLinejoin=\"round\" strokeWidth={2} d=\"M4 6h16M4 10h16M4 14h16M4 18h16\" />
                </svg>
                Browse Notes
              </Link>
            </div>
          </div>

          {/* Vulnerability Demo */}
          <div className=\"card p-6 border-red-200 bg-red-50\">
            <h3 className=\"text-lg font-semibold text-red-900 mb-2\">Security Demo</h3>
            <p className=\"text-sm text-red-700 mb-4\">
              Explore the deliberately vulnerable features for educational purposes.
            </p>
            <Link
              to=\"/vulnerability-demo\"
              className=\"btn-danger w-full flex items-center justify-center\"
            >
              <svg className=\"h-5 w-5 mr-2\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\">
                <path strokeLinecap=\"round\" strokeLinejoin=\"round\" strokeWidth={2} d=\"M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z\" />
              </svg>
              Vuln Demo
            </Link>
          </div>

          {/* Account Status */}
          <div className=\"card p-6\">
            <h3 className=\"text-lg font-semibold text-gray-900 mb-4\">Account Status</h3>
            <div className=\"space-y-3 text-sm\">
              <div className=\"flex justify-between\">
                <span className=\"text-gray-600\">Email:</span>
                <span className=\"font-medium\">{user.email}</span>
              </div>
              <div className=\"flex justify-between\">
                <span className=\"text-gray-600\">Verified:</span>
                <span className={`font-medium ${user.isEmailVerified ? 'text-green-600' : 'text-red-600'}`}>
                  {user.isEmailVerified ? 'Yes' : 'No'}
                </span>
              </div>
              <div className=\"flex justify-between\">
                <span className=\"text-gray-600\">Member since:</span>
                <span className=\"font-medium\">
                  {new Date(user.createdAt || Date.now()).toLocaleDateString()}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
