import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { authAPI, vulnerabilityAPI } from '../services/api';

const EmailVerification = () => {
  const [verificationStatus, setVerificationStatus] = useState('pending');
  const [verificationResult, setVerificationResult] = useState(null);
  const [vulnerabilityDetected, setVulnerabilityDetected] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    // VULNERABILITY: Client-side path traversal in hash parameter processing
    // This mimics the Netlify vulnerability where verification tokens were processed client-side
    handleEmailVerification();
  }, []);

  const handleEmailVerification = async () => {
    setLoading(true);
    
    try {
      // VULNERABILITY: Parse hash parameter without validation
      // In the Netlify bug, tokens like #verify_token=../user?email=attacker@example.com
      // would cause client-side JavaScript to make requests to wrong endpoints
      
      const hash = window.location.hash;
      console.log('🔍 Processing URL hash:', hash);
      
      if (!hash || !hash.includes('verify_token=')) {
        setVerificationStatus('no_token');
        setLoading(false);
        return;
      }

      // Extract token from hash (VULNERABLE CODE)
      const tokenMatch = hash.match(/verify_token=([^&]+)/);
      if (!tokenMatch) {
        setVerificationStatus('invalid_format');
        setLoading(false);
        return;
      }

      const token = decodeURIComponent(tokenMatch[1]);
      console.log('🎯 Extracted verification token:', token);

      // VULNERABILITY: Check for path traversal patterns
      if (token.includes('../')) {
        console.log('⚠️  CRITICAL VULNERABILITY DETECTED: Path traversal in verification token!');
        setVulnerabilityDetected(true);
        
        // VULNERABILITY: Client-side code that would make request to wrong endpoint
        // In the real Netlify bug, this would resolve to /api/v1/user?email=attacker@example.com
        const pathTraversalMatch = token.match(/\\.\\.\\/(\\w+)\\?email=([^&]+)/);
        if (pathTraversalMatch) {
          const endpoint = pathTraversalMatch[1]; // e.g., \"user\"
          const attackerEmail = pathTraversalMatch[2];
          
          console.log(`💀 ATTACK DETECTED: Would redirect to /${endpoint}?email=${attackerEmail}`);
          console.log(`💀 This would bind email ${attackerEmail} to the current user's account!`);
          
          // Demonstrate the vulnerability
          const vulnResult = await vulnerabilityAPI.demonstratePathTraversal(token);
          setVerificationResult({
            type: 'vulnerability',
            data: vulnResult,
            attackerEmail: attackerEmail,
            endpoint: endpoint
          });
          setVerificationStatus('vulnerability_demo');
          setLoading(false);
          return;
        }
      }

      // Normal verification flow
      console.log('✅ Processing normal verification token');
      const result = await authAPI.verifyEmail(token);
      setVerificationResult(result);
      setVerificationStatus('success');
      
      toast.success('Email verified successfully!');
      
      // Redirect after successful verification
      setTimeout(() => {
        navigate('/dashboard');
      }, 2000);

    } catch (error) {
      console.error('Email verification error:', error);
      setVerificationResult(error.response?.data || { error: error.message });
      setVerificationStatus('error');
      toast.error('Email verification failed');
    } finally {
      setLoading(false);
    }
  };

  const handleManualVerification = async () => {
    const token = document.getElementById('manual-token').value;
    if (!token) {
      toast.error('Please enter a verification token');
      return;
    }

    setLoading(true);
    try {
      const result = await authAPI.verifyEmail(token);
      setVerificationResult(result);
      setVerificationStatus('success');
      toast.success('Email verified successfully!');
    } catch (error) {
      setVerificationResult(error.response?.data || { error: error.message });
      setVerificationStatus('error');
      toast.error('Verification failed');
    } finally {
      setLoading(false);
    }
  };

  const renderVulnerabilityDemo = () => {
    if (!vulnerabilityDetected || verificationStatus !== 'vulnerability_demo') return null;

    return (
      <div className=\"vulnerability-warning\">
        <div className=\"flex\">
          <div className=\"flex-shrink-0\">
            <svg className=\"h-5 w-5 text-red-400\" viewBox=\"0 0 20 20\" fill=\"currentColor\">
              <path fillRule=\"evenodd\" d=\"M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z\" clipRule=\"evenodd\" />
            </svg>
          </div>
          <div className=\"ml-3\">
            <h3 className=\"text-sm font-medium text-red-800\">
              🚨 CRITICAL SECURITY VULNERABILITY DETECTED
            </h3>
            <div className=\"mt-2 text-sm text-red-700\">
              <p><strong>Vulnerability Type:</strong> Client-Side Path Traversal</p>
              <p><strong>Attack Vector:</strong> Malicious verification token</p>
              <p><strong>Impact:</strong> Account takeover via email binding</p>
              
              {verificationResult?.attackerEmail && (
                <div className=\"mt-4 p-3 bg-red-100 rounded\">
                  <p><strong>Detected Attack:</strong></p>
                  <p>• Target email: <code>{verificationResult.attackerEmail}</code></p>
                  <p>• Malicious endpoint: <code>/{verificationResult.endpoint}</code></p>
                  <p>• Result: This would bind the attacker's email to the victim's account!</p>
                </div>
              )}

              <div className=\"mt-4 p-3 bg-yellow-100 rounded\">
                <p><strong>How this vulnerability works:</strong></p>
                <ol className=\"list-decimal list-inside mt-2 space-y-1\">
                  <li>Attacker sends victim a link: <code>example.com/verify#verify_token=../user?email=attacker@evil.com</code></li>
                  <li>Client-side JavaScript processes the hash parameter</li>
                  <li>Path traversal redirects to <code>/api/v1/user?email=attacker@evil.com</code></li>
                  <li>Backend binds attacker's email to victim's account</li>
                  <li>Attacker can now reset victim's password using their email</li>
                  <li>Complete account takeover achieved!</li>
                </ol>
              </div>

              {verificationResult?.data && (
                <div className=\"mt-4 p-3 bg-gray-100 rounded\">
                  <p><strong>Server Response:</strong></p>
                  <pre className=\"text-xs overflow-auto\">{JSON.stringify(verificationResult.data, null, 2)}</pre>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className=\"min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8\">
      <div className=\"sm:mx-auto sm:w-full sm:max-w-md\">
        <div className=\"text-center\">
          <h2 className=\"mt-6 text-3xl font-extrabold text-gray-900\">
            Email Verification
          </h2>
          <p className=\"mt-2 text-sm text-gray-600\">
            Verify your email address to complete registration
          </p>
        </div>
      </div>

      <div className=\"mt-8 sm:mx-auto sm:w-full sm:max-w-2xl\">
        <div className=\"card px-6 py-8 sm:px-8\">
          {loading && (
            <div className=\"text-center mb-6\">
              <div className=\"animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600 mx-auto\"></div>
              <p className=\"mt-2 text-sm text-gray-600\">Processing verification...</p>
            </div>
          )}

          {renderVulnerabilityDemo()}

          {verificationStatus === 'no_token' && (
            <div className=\"text-center\">
              <div className=\"mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-yellow-100 mb-4\">
                <svg className=\"h-6 w-6 text-yellow-600\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\">
                  <path strokeLinecap=\"round\" strokeLinejoin=\"round\" strokeWidth={2} d=\"M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z\" />
                </svg>
              </div>
              <h3 className=\"text-lg font-medium text-gray-900 mb-2\">No Verification Token</h3>
              <p className=\"text-gray-600 mb-6\">
                Please check your email for the verification link, or enter your token manually below.
              </p>
              
              <div className=\"space-y-4\">
                <div>
                  <label htmlFor=\"manual-token\" className=\"block text-sm font-medium text-gray-700 mb-2\">
                    Verification Token
                  </label>
                  <input
                    type=\"text\"
                    id=\"manual-token\"
                    className=\"input-field\"
                    placeholder=\"Enter your verification token\"
                  />
                </div>
                <button
                  onClick={handleManualVerification}
                  disabled={loading}
                  className=\"btn-primary w-full\"
                >
                  Verify Email
                </button>
              </div>
            </div>
          )}

          {verificationStatus === 'success' && verificationResult && (
            <div className=\"text-center\">
              <div className=\"mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100 mb-4\">
                <svg className=\"h-6 w-6 text-green-600\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\">
                  <path strokeLinecap=\"round\" strokeLinejoin=\"round\" strokeWidth={2} d=\"M5 13l4 4L19 7\" />
                </svg>
              </div>
              <h3 className=\"text-lg font-medium text-gray-900 mb-2\">Email Verified Successfully!</h3>
              <p className=\"text-gray-600 mb-4\">
                Your email has been verified. You'll be redirected to your dashboard shortly.
              </p>
              {verificationResult.user && (
                <div className=\"bg-green-50 p-4 rounded-lg\">
                  <p className=\"text-sm text-green-800\">
                    Welcome, {verificationResult.user.username}! Your account is now fully activated.
                  </p>
                </div>
              )}
            </div>
          )}

          {verificationStatus === 'error' && verificationResult && (
            <div className=\"text-center\">
              <div className=\"mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100 mb-4\">
                <svg className=\"h-6 w-6 text-red-600\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\">
                  <path strokeLinecap=\"round\" strokeLinejoin=\"round\" strokeWidth={2} d=\"M6 18L18 6M6 6l12 12\" />
                </svg>
              </div>
              <h3 className=\"text-lg font-medium text-gray-900 mb-2\">Verification Failed</h3>
              <p className=\"text-gray-600 mb-4\">
                {verificationResult.error || 'An error occurred during verification.'}
              </p>
              <button
                onClick={() => navigate('/login')}
                className=\"btn-secondary\"
              >
                Back to Login
              </button>
            </div>
          )}

          {/* Educational Information */}
          <div className=\"vulnerability-info mt-8\">
            <div className=\"flex\">
              <div className=\"flex-shrink-0\">
                <svg className=\"h-5 w-5 text-yellow-400\" viewBox=\"0 0 20 20\" fill=\"currentColor\">
                  <path fillRule=\"evenodd\" d=\"M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z\" clipRule=\"evenodd\" />
                </svg>
              </div>
              <div className=\"ml-3\">
                <h3 className=\"text-sm font-medium text-yellow-800\">
                  Educational Security Demonstration
                </h3>
                <div className=\"mt-2 text-sm text-yellow-700\">
                  <p>This component demonstrates a real vulnerability found in Netlify (Report #3307106):</p>
                  <ul className=\"list-disc list-inside mt-2 space-y-1\">
                    <li><strong>Client-side path traversal</strong> in URL hash processing</li>
                    <li><strong>Insecure email binding</strong> via query parameters</li>
                    <li><strong>Missing input validation</strong> on verification tokens</li>
                  </ul>
                  <p className=\"mt-2\">
                    <strong>Try it:</strong> Use a URL like: 
                    <code className=\"bg-yellow-200 px-1 rounded text-xs\">
                      #verify_token=../user?email=attacker@example.com
                    </code>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmailVerification;
