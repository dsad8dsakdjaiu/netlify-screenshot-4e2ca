import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { notesAPI } from '../services/api';
import toast from 'react-hot-toast';

const Notes = ({ user }) => {
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    search: '',
    category: '',
    pinned: '',
    archived: 'false'
  });

  useEffect(() => {
    loadNotes();
  }, [filters]);

  const loadNotes = async () => {
    try {
      const cleanFilters = Object.fromEntries(
        Object.entries(filters).filter(([_, value]) => value !== '')
      );
      
      const data = await notesAPI.getNotes(cleanFilters);
      setNotes(data.notes);
    } catch (error) {
      console.error('Load notes error:', error);
      toast.error('Failed to load notes');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (noteId, noteTitle) => {
    if (!window.confirm(`Are you sure you want to delete \"${noteTitle}\"?`)) {
      return;
    }

    try {
      await notesAPI.deleteNote(noteId);
      setNotes(notes.filter(note => note._id !== noteId));
      toast.success('Note deleted successfully');
    } catch (error) {
      console.error('Delete note error:', error);
      toast.error('Failed to delete note');
    }
  };

  const handleArchive = async (noteId, archived) => {
    try {
      await notesAPI.archiveNote(noteId, archived);
      loadNotes(); // Reload notes
      toast.success(archived ? 'Note archived' : 'Note unarchived');
    } catch (error) {
      console.error('Archive note error:', error);
      toast.error('Failed to archive note');
    }
  };

  const categories = ['personal', 'work', 'study', 'project', 'idea', 'other'];

  if (loading) {
    return (
      <div className=\"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8\">
        <div className=\"animate-pulse space-y-4\">
          <div className=\"h-8 bg-gray-300 rounded w-1/4\"></div>
          <div className=\"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6\">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className=\"h-48 bg-gray-300 rounded-lg\"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className=\"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8\">
      {/* Header */}
      <div className=\"flex flex-col md:flex-row md:items-center md:justify-between mb-8\">
        <div>
          <h1 className=\"text-3xl font-bold text-gray-900\">My Notes</h1>
          <p className=\"mt-2 text-gray-600\">
            {notes.length} {notes.length === 1 ? 'note' : 'notes'} found
          </p>
        </div>
        <div className=\"mt-4 md:mt-0\">
          <Link to=\"/notes/new\" className=\"btn-primary\">
            <svg className=\"h-5 w-5 mr-2\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\">
              <path strokeLinecap=\"round\" strokeLinejoin=\"round\" strokeWidth={2} d=\"M12 6v6m0 0v6m0-6h6m-6 0H6\" />
            </svg>
            New Note
          </Link>
        </div>
      </div>

      {/* Filters */}
      <div className=\"card p-6 mb-8\">
        <div className=\"grid grid-cols-1 md:grid-cols-4 gap-4\">
          <div>
            <label className=\"block text-sm font-medium text-gray-700 mb-2\">Search</label>
            <input
              type=\"text\"
              value={filters.search}
              onChange={(e) => setFilters({ ...filters, search: e.target.value })}
              className=\"input-field\"
              placeholder=\"Search notes...\"
            />
          </div>
          
          <div>
            <label className=\"block text-sm font-medium text-gray-700 mb-2\">Category</label>
            <select
              value={filters.category}
              onChange={(e) => setFilters({ ...filters, category: e.target.value })}
              className=\"input-field\"
            >
              <option value=\"\">All categories</option>
              {categories.map(cat => (
                <option key={cat} value={cat} className=\"capitalize\">{cat}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className=\"block text-sm font-medium text-gray-700 mb-2\">Status</label>
            <select
              value={filters.pinned}
              onChange={(e) => setFilters({ ...filters, pinned: e.target.value })}
              className=\"input-field\"
            >
              <option value=\"\">All notes</option>
              <option value=\"true\">Pinned only</option>
              <option value=\"false\">Not pinned</option>
            </select>
          </div>
          
          <div>
            <label className=\"block text-sm font-medium text-gray-700 mb-2\">Archive</label>
            <select
              value={filters.archived}
              onChange={(e) => setFilters({ ...filters, archived: e.target.value })}
              className=\"input-field\"
            >
              <option value=\"false\">Active notes</option>
              <option value=\"true\">Archived notes</option>
              <option value=\"\">All notes</option>
            </select>
          </div>
        </div>
      </div>

      {/* Notes Grid */}
      {notes.length === 0 ? (
        <div className=\"text-center py-12\">
          <svg className=\"mx-auto h-12 w-12 text-gray-400\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\">
            <path strokeLinecap=\"round\" strokeLinejoin=\"round\" strokeWidth={2} d=\"M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z\" />
          </svg>
          <h3 className=\"mt-2 text-sm font-medium text-gray-900\">No notes found</h3>
          <p className=\"mt-1 text-sm text-gray-500\">Get started by creating your first note.</p>
          <div className=\"mt-6\">
            <Link to=\"/notes/new\" className=\"btn-primary\">
              Create Note
            </Link>
          </div>
        </div>
      ) : (
        <div className=\"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6\">
          {notes.map((note) => (
            <div key={note._id} className=\"note-card relative group\">
              {/* Note Header */}
              <div className=\"flex items-start justify-between mb-3\">
                <div className=\"flex-1\">
                  <h3 className=\"text-lg font-semibold text-gray-900 mb-1\">{note.title}</h3>
                  <div className=\"flex items-center space-x-2 text-xs text-gray-500\">
                    <span className=\"capitalize bg-gray-100 px-2 py-1 rounded\">{note.category}</span>
                    {note.isPinned && (
                      <span className=\"bg-yellow-100 text-yellow-800 px-2 py-1 rounded\">Pinned</span>
                    )}
                    {note.isArchived && (
                      <span className=\"bg-gray-200 text-gray-700 px-2 py-1 rounded\">Archived</span>
                    )}
                    {note.isPublic && (
                      <span className=\"bg-green-100 text-green-800 px-2 py-1 rounded\">Public</span>
                    )}
                  </div>
                </div>
                
                {/* Action Menu */}
                <div className=\"opacity-0 group-hover:opacity-100 transition-opacity duration-200\">
                  <div className=\"flex items-center space-x-1\">
                    <Link
                      to={`/notes/${note._id}`}
                      className=\"p-1 text-gray-400 hover:text-gray-600\"
                      title=\"Edit\"
                    >
                      <svg className=\"h-4 w-4\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\">
                        <path strokeLinecap=\"round\" strokeLinejoin=\"round\" strokeWidth={2} d=\"M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z\" />
                      </svg>
                    </Link>
                    
                    <button
                      onClick={() => handleArchive(note._id, !note.isArchived)}
                      className=\"p-1 text-gray-400 hover:text-gray-600\"
                      title={note.isArchived ? 'Unarchive' : 'Archive'}
                    >
                      <svg className=\"h-4 w-4\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\">
                        <path strokeLinecap=\"round\" strokeLinejoin=\"round\" strokeWidth={2} d=\"M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4\" />
                      </svg>
                    </button>
                    
                    <button
                      onClick={() => handleDelete(note._id, note.title)}
                      className=\"p-1 text-gray-400 hover:text-red-600\"
                      title=\"Delete\"
                    >
                      <svg className=\"h-4 w-4\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\">
                        <path strokeLinecap=\"round\" strokeLinejoin=\"round\" strokeWidth={2} d=\"M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16\" />
                      </svg>
                    </button>
                  </div>
                </div>
              </div>

              {/* Note Content */}
              <p className=\"text-gray-600 text-sm mb-4 line-clamp-4\">{note.excerpt}</p>

              {/* Note Tags */}
              {note.tags && note.tags.length > 0 && (
                <div className=\"flex flex-wrap gap-1 mb-3\">
                  {note.tags.slice(0, 3).map((tag, index) => (
                    <span
                      key={index}
                      className=\"inline-block px-2 py-1 text-xs bg-blue-100 text-blue-700 rounded\"
                    >
                      {tag}
                    </span>
                  ))}
                  {note.tags.length > 3 && (
                    <span className=\"inline-block px-2 py-1 text-xs bg-gray-100 text-gray-600 rounded\">
                      +{note.tags.length - 3}
                    </span>
                  )}
                </div>
              )}

              {/* Note Footer */}
              <div className=\"flex items-center justify-between text-xs text-gray-500\">
                <span>Updated {new Date(note.updatedAt).toLocaleDateString()}</span>
                <div className=\"flex items-center space-x-3\">
                  <span>{note.viewCount || 0} views</span>
                  <span>v{note.version || 1}</span>
                </div>
              </div>

              {/* Click overlay for navigation */}
              <Link
                to={`/notes/${note._id}`}
                className=\"absolute inset-0 z-0\"
                aria-label={`Edit note: ${note.title}`}
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Notes;
