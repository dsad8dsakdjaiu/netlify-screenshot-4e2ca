import React, { useState } from 'react';
import { updateUserProfile } from '../services/api';
import toast from 'react-hot-toast';

const Profile = ({ user, setUser }) => {
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('profile');
  const [formData, setFormData] = useState({
    username: user.username,
    email: user.email,
    preferences: {
      theme: user.preferences?.theme || 'light',
      fontSize: user.preferences?.fontSize || 'medium',
      language: user.preferences?.language || 'en'
    }
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const result = await updateUserProfile(formData);
      setUser(result.user);
      toast.success('Profile updated successfully');
    } catch (error) {
      console.error('Profile update error:', error);
      toast.error(error.response?.data?.error || 'Failed to update profile');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    
    if (name.startsWith('preferences.')) {
      const prefKey = name.split('.')[1];
      setFormData({
        ...formData,
        preferences: {
          ...formData.preferences,
          [prefKey]: value
        }
      });
    } else {
      setFormData({
        ...formData,
        [name]: value
      });
    }
  };

  const tabs = [
    { id: 'profile', label: 'Profile', icon: 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z' },
    { id: 'preferences', label: 'Preferences', icon: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z' },
    { id: 'security', label: 'Security', icon: 'M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z' }
  ];

  return (
    <div className=\"max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8\">
      {/* Header */}
      <div className=\"mb-8\">
        <h1 className=\"text-3xl font-bold text-gray-900\">Account Settings</h1>
        <p className=\"mt-2 text-gray-600\">Manage your account preferences and security settings</p>
      </div>

      {/* Email Verification Warning */}
      {!user.isEmailVerified && (
        <div className=\"mb-8 p-4 bg-yellow-50 border-l-4 border-yellow-400\">
          <div className=\"flex\">
            <div className=\"flex-shrink-0\">
              <svg className=\"h-5 w-5 text-yellow-400\" viewBox=\"0 0 20 20\" fill=\"currentColor\">
                <path fillRule=\"evenodd\" d=\"M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z\" clipRule=\"evenodd\" />
              </svg>
            </div>
            <div className=\"ml-3\">
              <p className=\"text-sm text-yellow-700\">
                <strong>Email not verified:</strong> Please verify your email address to secure your account.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab Navigation */}
      <div className=\"border-b border-gray-200 mb-8\">
        <nav className=\"-mb-px flex space-x-8\">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === tab.id
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <svg className=\"h-5 w-5\" fill=\"none\" viewBox=\"0 0 24 24\" stroke=\"currentColor\">
                <path strokeLinecap=\"round\" strokeLinejoin=\"round\" strokeWidth={2} d={tab.icon} />
              </svg>
              <span>{tab.label}</span>
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      <div className=\"grid grid-cols-1 lg:grid-cols-3 gap-8\">
        <div className=\"lg:col-span-2\">
          {activeTab === 'profile' && (
            <div className=\"card p-8\">
              <h2 className=\"text-xl font-semibold text-gray-900 mb-6\">Profile Information</h2>
              
              <form onSubmit={handleSubmit} className=\"space-y-6\">
                <div>
                  <label htmlFor=\"username\" className=\"block text-sm font-medium text-gray-700 mb-2\">
                    Username
                  </label>
                  <input
                    type=\"text\"
                    id=\"username\"
                    name=\"username\"
                    value={formData.username}
                    onChange={handleChange}
                    className=\"input-field\"
                    required
                  />
                </div>

                <div>
                  <label htmlFor=\"email\" className=\"block text-sm font-medium text-gray-700 mb-2\">
                    Email Address
                  </label>
                  <input
                    type=\"email\"
                    id=\"email\"
                    name=\"email\"
                    value={formData.email}
                    onChange={handleChange}
                    className=\"input-field\"
                    required
                  />
                  {!user.isEmailVerified && (
                    <p className=\"mt-1 text-sm text-red-600\">⚠️ Email not verified</p>
                  )}
                </div>

                <div className=\"flex justify-end\">
                  <button
                    type=\"submit\"
                    disabled={loading}
                    className=\"btn-primary\"
                  >
                    {loading ? 'Updating...' : 'Update Profile'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {activeTab === 'preferences' && (
            <div className=\"card p-8\">
              <h2 className=\"text-xl font-semibold text-gray-900 mb-6\">Preferences</h2>
              
              <form onSubmit={handleSubmit} className=\"space-y-6\">
                <div>
                  <label htmlFor=\"theme\" className=\"block text-sm font-medium text-gray-700 mb-2\">
                    Theme
                  </label>
                  <select
                    id=\"theme\"
                    name=\"preferences.theme\"
                    value={formData.preferences.theme}
                    onChange={handleChange}
                    className=\"input-field\"
                  >
                    <option value=\"light\">Light</option>
                    <option value=\"dark\">Dark</option>
                    <option value=\"auto\">Auto</option>
                  </select>
                </div>

                <div>
                  <label htmlFor=\"fontSize\" className=\"block text-sm font-medium text-gray-700 mb-2\">
                    Font Size
                  </label>
                  <select
                    id=\"fontSize\"
                    name=\"preferences.fontSize\"
                    value={formData.preferences.fontSize}
                    onChange={handleChange}
                    className=\"input-field\"
                  >
                    <option value=\"small\">Small</option>
                    <option value=\"medium\">Medium</option>
                    <option value=\"large\">Large</option>
                  </select>
                </div>

                <div>
                  <label htmlFor=\"language\" className=\"block text-sm font-medium text-gray-700 mb-2\">
                    Language
                  </label>
                  <select
                    id=\"language\"
                    name=\"preferences.language\"
                    value={formData.preferences.language}
                    onChange={handleChange}
                    className=\"input-field\"
                  >
                    <option value=\"en\">English</option>
                    <option value=\"es\">Español</option>
                    <option value=\"fr\">Français</option>
                    <option value=\"de\">Deutsch</option>
                  </select>
                </div>

                <div className=\"flex justify-end\">
                  <button
                    type=\"submit\"
                    disabled={loading}
                    className=\"btn-primary\"
                  >
                    {loading ? 'Saving...' : 'Save Preferences'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {activeTab === 'security' && (
            <div className=\"space-y-6\">
              <div className=\"card p-8\">
                <h2 className=\"text-xl font-semibold text-gray-900 mb-6\">Security Settings</h2>
                
                <div className=\"space-y-6\">
                  <div className=\"flex items-center justify-between\">
                    <div>
                      <h3 className=\"text-lg font-medium text-gray-900\">Email Verification</h3>
                      <p className=\"text-sm text-gray-600\">Verify your email address to secure your account</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${ 
                      user.isEmailVerified 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {user.isEmailVerified ? 'Verified' : 'Not Verified'}
                    </span>
                  </div>

                  <div className=\"flex items-center justify-between\">
                    <div>
                      <h3 className=\"text-lg font-medium text-gray-900\">Password</h3>
                      <p className=\"text-sm text-gray-600\">Last changed: Never</p>
                    </div>
                    <button className=\"btn-secondary\" disabled>
                      Change Password
                    </button>
                  </div>

                  <div className=\"flex items-center justify-between\">
                    <div>
                      <h3 className=\"text-lg font-medium text-gray-900\">Two-Factor Authentication</h3>
                      <p className=\"text-sm text-gray-600\">Add an extra layer of security</p>
                    </div>
                    <button className=\"btn-secondary\" disabled>
                      Enable 2FA
                    </button>
                  </div>
                </div>
              </div>

              <div className=\"card p-8 border-red-200 bg-red-50\">
                <h2 className=\"text-xl font-semibold text-red-900 mb-4\">Danger Zone</h2>
                <p className=\"text-sm text-red-700 mb-6\">
                  These actions are irreversible. Please be careful.
                </p>
                
                <button className=\"btn-danger\" disabled>
                  Delete Account
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Sidebar */}
        <div className=\"space-y-6\">
          <div className=\"card p-6\">
            <h3 className=\"text-lg font-semibold text-gray-900 mb-4\">Account Overview</h3>
            <div className=\"space-y-3 text-sm\">
              <div className=\"flex justify-between\">
                <span className=\"text-gray-600\">Username:</span>
                <span className=\"font-medium\">{user.username}</span>
              </div>
              <div className=\"flex justify-between\">
                <span className=\"text-gray-600\">Email:</span>
                <span className=\"font-medium\">{user.email}</span>
              </div>
              <div className=\"flex justify-between\">
                <span className=\"text-gray-600\">Verified:</span>
                <span className={`font-medium ${user.isEmailVerified ? 'text-green-600' : 'text-red-600'}`}>
                  {user.isEmailVerified ? 'Yes' : 'No'}
                </span>
              </div>
              <div className=\"flex justify-between\">
                <span className=\"text-gray-600\">Member since:</span>
                <span className=\"font-medium\">
                  {new Date(user.createdAt || Date.now()).toLocaleDateString()}
                </span>
              </div>
            </div>
          </div>

          <div className=\"card p-6\">
            <h3 className=\"text-lg font-semibold text-gray-900 mb-4\">Security Status</h3>
            <div className=\"space-y-3\">
              <div className=\"flex items-center space-x-2\">
                <div className={`w-3 h-3 rounded-full ${user.isEmailVerified ? 'bg-green-500' : 'bg-red-500'}`}></div>
                <span className=\"text-sm\">Email Verification</span>
              </div>
              <div className=\"flex items-center space-x-2\">
                <div className=\"w-3 h-3 rounded-full bg-red-500\"></div>
                <span className=\"text-sm\">Two-Factor Auth</span>
              </div>
              <div className=\"flex items-center space-x-2\">
                <div className=\"w-3 h-3 rounded-full bg-red-500\"></div>
                <span className=\"text-sm\">Strong Password</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
