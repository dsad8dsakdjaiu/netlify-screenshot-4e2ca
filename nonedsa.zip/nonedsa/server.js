const express = require('express');
const mongoose = require('mongoose');
const cookieParser = require('cookie-parser');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const userRoutes = require('./routes/user');
const notesRoutes = require('./routes/notes');

const app = express();

// Database connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/vulnerable_notes_db', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('Connected to MongoDB'))
.catch(err => console.error('MongoDB connection error:', err));

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// CORS configuration - deliberately permissive for vulnerabilities
app.use(cors({
  origin: ['http://localhost:3000', 'http://127.0.0.1:3000'],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'Cookie']
}));

// VULNERABILITY: No CSRF protection middleware
// In a secure app, you would add CSRF tokens here
console.log('⚠️  SECURITY WARNING: CSRF protection is DISABLED for educational purposes');

// Security headers middleware (deliberately weak)
app.use((req, res, next) => {
  // VULNERABILITY: Missing security headers
  res.header('X-Powered-By', 'Vulnerable-Notes-App/1.0.0'); // Information disclosure
  
  // Deliberately permissive CSP for client-side vulnerabilities
  res.header('Content-Security-Policy', "default-src 'self' 'unsafe-inline' 'unsafe-eval' *");
  
  next();
});

// Logging middleware for educational purposes
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
  if (req.query && Object.keys(req.query).length > 0) {
    console.log('Query params:', req.query);
  }
  next();
});

// API Routes
app.use('/api/v1/user', userRoutes);
app.use('/api/v1/notes', notesRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    vulnerabilities: {
      csrf_protection: false,
      email_validation: false,
      path_traversal_protection: false
    }
  });
});

// Serve static files from React build
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, 'client/build')));
  
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'client/build', 'index.html'));
  });
} else {
  app.get('/', (req, res) => {
    res.json({ 
      message: 'Vulnerable Notes API Server',
      frontend: 'http://localhost:3000',
      documentation: '/api/health'
    });
  });
}

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err);
  
  // VULNERABILITY: Information disclosure in error messages
  res.status(err.status || 500).json({
    error: err.message,
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined,
    timestamp: new Date().toISOString()
  });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📝 Notes API: http://localhost:${PORT}/api/v1/notes`);
  console.log(`👤 User API: http://localhost:${PORT}/api/v1/user`);
  console.log(`⚠️  This application contains DELIBERATE security vulnerabilities for educational purposes`);
  console.log(`⚠️  DO NOT deploy to production environments`);
});
