# Vulnerable Notes App 🚨

A deliberately vulnerable note-taking web application built for educational purposes, replicating real-world security vulnerabilities found in Netlify's bug bounty report #3307106.

## ⚠️ CRITICAL SECURITY WARNING

**This application contains DELIBERATE security vulnerabilities for educational purposes only.**

- **DO NOT** deploy this application to production environments
- **DO NOT** use this application with real user data
- **DO NOT** attempt these attacks on real systems without explicit permission
- **ONLY** use this for security education and training

## 🎯 Educational Purpose

This application demonstrates:
- **Client-side path traversal vulnerabilities**
- **Insecure email binding attacks**
- **Missing CSRF protection**
- **Account takeover scenarios**
- **Complete attack chains from reconnaissance to exploitation**

Based on real vulnerabilities discovered in Netlify's infrastructure that allowed complete account takeover with a single malicious link.

## 🏗️ Architecture

### Backend (Node.js + Express)
- **Authentication**: JWT-based with multiple cookie types
- **Database**: MongoDB with Mongoose ODM
- **API**: RESTful endpoints for users and notes
- **Vulnerabilities**: Deliberately implemented security flaws

### Frontend (React)
- **UI Framework**: Modern React with Tailwind CSS
- **State Management**: React hooks and context
- **Routing**: React Router with protected routes
- **Vulnerabilities**: Client-side path traversal in URL processing

## 📋 Prerequisites

Before running this application, ensure you have:

- **Node.js** (v16 or higher)
- **MongoDB** (v5.0 or higher)
- **npm** or **yarn** package manager
- **Git** for cloning the repository

## 🚀 Quick Start

### 1. Clone the Repository

```bash
git clone <repository-url>
cd vulnerable-notes-app
```

### 2. Install Dependencies

```bash
# Install backend dependencies
npm install

# Install frontend dependencies
cd client
npm install
cd ..
```

### 3. Environment Setup

```bash
# Copy environment template
cp env.example .env

# Edit .env file with your settings
# Default settings work for local development
```

### 4. Start MongoDB

```bash
# Using MongoDB service (Linux/macOS)
sudo systemctl start mongod

# Using Docker
docker run -d -p 27017:27017 mongo:latest

# Using MongoDB Atlas (cloud)
# Update MONGODB_URI in .env with your Atlas connection string
```

### 5. Start the Application

```bash
# Terminal 1: Start backend server
npm run dev

# Terminal 2: Start frontend development server
npm run client
```

### 6. Access the Application

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:5000
- **Health Check**: http://localhost:5000/api/health

## 🔐 Default Demo Account

For quick testing, use the demo login feature:
- Click "Quick Demo Login" on the login page
- This creates a demo account automatically

Or register a new account:
- Username: Any unique username
- Email: Any email format (verification is mocked)
- Password: Minimum 6 characters

## 🐛 Vulnerability Demonstrations

### 1. Client-Side Path Traversal

**Location**: `/email-verification` component
**Vulnerability**: URL hash parameter processing without validation

#### How to Demonstrate:

1. Register a new account or login
2. Navigate to: 
   ```
   http://localhost:3000/email-verification#verify_token=../user?email=attacker@evil.com
   ```
3. Observe the vulnerability detection and demonstration

#### Technical Details:

```javascript
// Vulnerable code in EmailVerification.jsx
const token = decodeURIComponent(tokenMatch[1]);

// Path traversal in token: "../user?email=attacker@evil.com"
// Client-side request resolves to: /api/v1/user?email=attacker@evil.com
```

### 2. Insecure Email Binding

**Location**: `/api/v1/user` PUT endpoint
**Vulnerability**: Accepts email updates via query parameters without validation

#### How to Demonstrate:

1. Login to your account
2. Go to the "Vulnerability Demo" page
3. Use the "Email Binding" tab
4. Enter attacker email and click "Demonstrate Email Binding"

#### Technical Details:

```javascript
// Vulnerable backend code in routes/user.js
const { email: queryEmail } = req.query;
const { email: bodyEmail } = req.body;

// Query parameter takes precedence - VULNERABILITY!
const newEmail = queryEmail || bodyEmail;

if (queryEmail) {
  user.updateEmailUnsafe(newEmail); // No validation!
}
```

### 3. Complete Attack Chain

**Scenario**: Full account takeover via single malicious link

#### Attack Steps:

1. **Social Engineering**: Attacker sends malicious link to victim
   ```
   http://localhost:3000/email-verification#verify_token=../user?email=attacker@evil.com
   ```

2. **Path Traversal**: Victim clicks link while authenticated
   - Client-side JavaScript processes hash parameter
   - Path traversal redirects to `/api/v1/user?email=attacker@evil.com`

3. **Email Binding**: Backend binds attacker's email to victim's account
   - No CSRF protection
   - No email confirmation required
   - Query parameter overrides body data

4. **Password Reset**: Attacker requests password reset
   - Reset link sent to attacker's email
   - For victim's account

5. **Account Takeover**: Attacker gains full access
   - Can read/modify/delete all victim's notes
   - Can change account settings
   - Complete compromise achieved

## 🛡️ Security Issues Demonstrated

### 1. Input Validation Failures
- **Issue**: URL parameters processed without sanitization
- **Impact**: Path traversal attacks possible
- **Mitigation**: Validate and sanitize all user inputs

### 2. Missing CSRF Protection
- **Issue**: State-changing requests lack CSRF tokens
- **Impact**: Cross-site request forgery attacks
- **Mitigation**: Implement CSRF tokens for all state changes

### 3. Insecure Parameter Handling
- **Issue**: Query parameters override request body
- **Impact**: Unintended data modification
- **Mitigation**: Consistent parameter precedence and validation

### 4. Weak Authentication Flow
- **Issue**: Email changes without confirmation
- **Impact**: Account takeover via email binding
- **Mitigation**: Require email confirmation for changes

### 5. Information Disclosure
- **Issue**: Detailed error messages and stack traces
- **Impact**: System information leakage
- **Mitigation**: Generic error messages in production

## 🎓 Educational Usage

### For Security Courses

1. **Vulnerability Analysis**: Study the vulnerable code
2. **Attack Simulation**: Practice exploitation techniques
3. **Defense Implementation**: Fix the vulnerabilities
4. **Security Testing**: Develop testing methodologies

### For Bug Bounty Training

1. **Reconnaissance**: Learn to identify vulnerable patterns
2. **Exploitation**: Practice attack chaining
3. **Reporting**: Document vulnerabilities professionally
4. **Impact Assessment**: Understand business impact

### For Development Teams

1. **Secure Coding**: Learn secure development practices
2. **Code Review**: Practice identifying vulnerabilities
3. **Testing**: Implement security testing processes
4. **Awareness**: Understand common vulnerability patterns

## 🔧 Development Commands

```bash
# Backend development
npm run dev          # Start backend with nodemon
npm start           # Start backend in production mode

# Frontend development
npm run client      # Start React development server
npm run build       # Build production frontend

# Full stack
npm run install-client  # Install frontend dependencies
```

## 📁 Project Structure

```
vulnerable-notes-app/
├── server.js                 # Main server file
├── routes/
│   ├── user.js              # User authentication & vulnerable endpoints
│   └── notes.js             # Notes CRUD operations
├── models/
│   ├── User.js              # User database schema
│   └── Note.js              # Note database schema
├── middleware/
│   └── auth.js              # JWT authentication middleware
├── client/
│   ├── src/
│   │   ├── components/      # React components
│   │   ├── services/        # API service layer
│   │   └── App.jsx          # Main React application
│   ├── public/              # Static assets
│   └── package.json         # Frontend dependencies
├── package.json             # Backend dependencies
├── env.example              # Environment template
└── README.md               # This file
```

## 🐛 Deliberate Vulnerabilities Map

| Component | Vulnerability | Severity | Educational Value |
|-----------|---------------|----------|-------------------|
| EmailVerification.jsx | Client-side path traversal | Critical | URL manipulation attacks |
| routes/user.js | Insecure email binding | Critical | Parameter pollution |
| routes/user.js | Missing CSRF protection | High | Cross-site request forgery |
| server.js | Information disclosure | Medium | Error handling security |
| auth.js | Weak token validation | Medium | Authentication bypasses |

## 🔍 Testing the Vulnerabilities

### Manual Testing

1. **Path Traversal Test**:
   ```bash
   curl -X POST http://localhost:5000/api/v1/user/verify-email \
     -H "Content-Type: application/json" \
     -d '{"token": "../user?email=test@attacker.com"}'
   ```

2. **Email Binding Test**:
   ```bash
   curl -X PUT "http://localhost:5000/api/v1/user?email=attacker@evil.com" \
     -H "Authorization: Bearer YOUR_JWT_TOKEN" \
     -H "Content-Type: application/json" \
     -d '{"preferences": {"theme": "dark"}}'
   ```

### Automated Testing

```javascript
// Example test case for vulnerability
const response = await request(app)
  .post('/api/v1/user/verify-email')
  .send({ token: '../user?email=attacker@evil.com' });

expect(response.body.vulnerability).toBe('PATH_TRAVERSAL_DETECTED');
```

## 📚 Learning Resources

### Related CVEs and Reports
- **Netlify Bug Bounty #3307106**: Original vulnerability report
- **CVE-2021-44228**: Log4j path traversal (similar concepts)
- **OWASP Top 10**: A03:2021 – Injection vulnerabilities

### Security Documentation
- [OWASP Web Security Testing Guide](https://owasp.org/www-project-web-security-testing-guide/)
- [PortSwigger Web Security Academy](https://portswigger.net/web-security)
- [NIST Cybersecurity Framework](https://www.nist.gov/cyberframework)

### Bug Bounty Platforms
- [HackerOne](https://hackerone.com/)
- [Bugcrowd](https://bugcrowd.com/)
- [Intigriti](https://intigriti.com/)

## 🤝 Contributing

This project is for educational purposes. If you'd like to contribute:

1. **Add new vulnerabilities** with educational value
2. **Improve documentation** and explanations
3. **Create additional test cases** and scenarios
4. **Enhance the user interface** for better learning experience

### Contribution Guidelines

- Maintain the educational focus
- Document all vulnerabilities clearly
- Include mitigation strategies
- Test thoroughly before submitting

## 📄 License

This project is released under the MIT License for educational purposes only.

**Usage Restrictions**:
- Educational and training purposes only
- No production deployment
- No real user data
- Responsible disclosure practices

## ⚖️ Legal Disclaimer

This software is provided for educational purposes only. The authors are not responsible for any misuse of this application. Users must:

- Only test on systems they own or have explicit permission to test
- Follow responsible disclosure practices
- Comply with all applicable laws and regulations
- Use this software ethically and responsibly

## 📞 Support and Questions

For educational support or questions about the vulnerabilities:

1. **Review the documentation** thoroughly
2. **Check the vulnerability demonstration** pages
3. **Study the commented code** for implementation details
4. **Practice in a safe, isolated environment**

---

**Remember**: The goal is to learn about security vulnerabilities to build more secure applications. Use this knowledge responsibly to make the web safer for everyone.

🛡️ **Stay secure, stay ethical!** 🛡️
