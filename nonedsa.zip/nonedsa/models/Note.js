const mongoose = require('mongoose');

const noteSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true,
    maxlength: 200
  },
  content: {
    type: String,
    required: true,
    maxlength: 50000 // Allow rich content
  },
  author: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  tags: [{
    type: String,
    trim: true,
    maxlength: 50
  }],
  category: {
    type: String,
    enum: ['personal', 'work', 'study', 'project', 'idea', 'other'],
    default: 'personal'
  },
  isPublic: {
    type: Boolean,
    default: false
  },
  isPinned: {
    type: Boolean,
    default: false
  },
  isArchived: {
    type: Boolean,
    default: false
  },
  // Rich text formatting support
  format: {
    type: String,
    enum: ['plain', 'markdown', 'rich'],
    default: 'plain'
  },
  // Collaboration features
  sharedWith: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    permission: {
      type: String,
      enum: ['read', 'write', 'admin'],
      default: 'read'
    },
    sharedAt: {
      type: Date,
      default: Date.now
    }
  }],
  // Version control
  version: {
    type: Number,
    default: 1
  },
  lastEditedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  // Metadata
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  },
  lastAccessedAt: {
    type: Date,
    default: Date.now
  },
  // Analytics
  viewCount: {
    type: Number,
    default: 0
  },
  editCount: {
    type: Number,
    default: 0
  }
}, {
  timestamps: true
});

// Indexes for performance
noteSchema.index({ author: 1, createdAt: -1 });
noteSchema.index({ author: 1, isPinned: -1, updatedAt: -1 });
noteSchema.index({ tags: 1 });
noteSchema.index({ title: 'text', content: 'text' }); // Text search

// Pre-save middleware
noteSchema.pre('save', function(next) {
  if (this.isModified('content') || this.isModified('title')) {
    this.updatedAt = new Date();
    this.version += 1;
    this.editCount += 1;
  }
  next();
});

// Method to increment view count
noteSchema.methods.incrementViewCount = function() {
  this.viewCount += 1;
  this.lastAccessedAt = new Date();
  return this.save();
};

// Method to check if user has access to note
noteSchema.methods.hasAccess = function(userId, permission = 'read') {
  // Owner always has full access
  if (this.author.toString() === userId.toString()) {
    return true;
  }
  
  // Check if note is public for read access
  if (permission === 'read' && this.isPublic) {
    return true;
  }
  
  // Check shared permissions
  const sharedAccess = this.sharedWith.find(share => 
    share.user.toString() === userId.toString()
  );
  
  if (!sharedAccess) return false;
  
  const permissionLevels = { 'read': 1, 'write': 2, 'admin': 3 };
  const requiredLevel = permissionLevels[permission] || 1;
  const userLevel = permissionLevels[sharedAccess.permission] || 1;
  
  return userLevel >= requiredLevel;
};

// Method to share note with user
noteSchema.methods.shareWith = function(userId, permission = 'read') {
  // Remove existing share if present
  this.sharedWith = this.sharedWith.filter(share => 
    share.user.toString() !== userId.toString()
  );
  
  // Add new share
  this.sharedWith.push({
    user: userId,
    permission: permission,
    sharedAt: new Date()
  });
  
  return this.save();
};

// Static method to find notes by user with optional filters
noteSchema.statics.findByUser = function(userId, filters = {}) {
  const query = { author: userId };
  
  if (filters.category) query.category = filters.category;
  if (filters.isPinned !== undefined) query.isPinned = filters.isPinned;
  if (filters.isArchived !== undefined) query.isArchived = filters.isArchived;
  if (filters.tags && filters.tags.length > 0) query.tags = { $in: filters.tags };
  
  return this.find(query).sort({ isPinned: -1, updatedAt: -1 });
};

// Static method for text search
noteSchema.statics.searchNotes = function(userId, searchTerm) {
  return this.find({
    $and: [
      { author: userId },
      {
        $or: [
          { title: { $regex: searchTerm, $options: 'i' } },
          { content: { $regex: searchTerm, $options: 'i' } },
          { tags: { $regex: searchTerm, $options: 'i' } }
        ]
      }
    ]
  }).sort({ updatedAt: -1 });
};

// Virtual for excerpt
noteSchema.virtual('excerpt').get(function() {
  if (!this.content) return '';
  return this.content.length > 150 
    ? this.content.substring(0, 150) + '...'
    : this.content;
});

// Ensure virtual fields are serialized
noteSchema.set('toJSON', {
  virtuals: true,
  transform: function(doc, ret) {
    delete ret.__v;
    return ret;
  }
});

module.exports = mongoose.model('Note', noteSchema);
