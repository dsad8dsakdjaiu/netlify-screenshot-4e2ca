const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    minlength: 3,
    maxlength: 50
  },
  email: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true
  },
  password: {
    type: String,
    required: true,
    minlength: 6
  },
  isEmailVerified: {
    type: Boolean,
    default: false
  },
  emailVerificationToken: {
    type: String,
    default: null
  },
  // User preferences for cookies
  preferences: {
    theme: {
      type: String,
      enum: ['light', 'dark', 'auto'],
      default: 'light'
    },
    fontSize: {
      type: String,
      enum: ['small', 'medium', 'large'],
      default: 'medium'
    },
    language: {
      type: String,
      default: 'en'
    }
  },
  // Analytics tracking
  analytics: {
    userId: {
      type: String,
      default: function() { return this._id.toString(); }
    },
    sessionCount: {
      type: Number,
      default: 0
    },
    lastLogin: {
      type: Date,
      default: null
    }
  },
  // Marketing preferences
  marketing: {
    acceptsEmails: {
      type: Boolean,
      default: true
    },
    adPersonalization: {
      type: Boolean,
      default: true
    },
    trackingId: {
      type: String,
      default: function() { return 'track_' + Math.random().toString(36).substr(2, 9); }
    }
  },
  // Account metadata
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  },
  lastPasswordReset: {
    type: Date,
    default: null
  }
}, {
  timestamps: true
});

// Pre-save middleware to hash password
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  
  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Method to compare password
userSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

// Method to generate email verification token
userSchema.methods.generateEmailVerificationToken = function() {
  // VULNERABILITY: Weak token generation
  // In a secure app, use crypto.randomBytes() or similar
  this.emailVerificationToken = 'verify_' + Math.random().toString(36).substr(2, 15);
  return this.emailVerificationToken;
};

// Method to verify email
userSchema.methods.verifyEmail = function() {
  this.isEmailVerified = true;
  this.emailVerificationToken = null;
  this.updatedAt = new Date();
};

// VULNERABILITY: Method that accepts email updates without validation
userSchema.methods.updateEmailUnsafe = function(newEmail) {
  console.log(`⚠️  VULNERABILITY: Updating email from ${this.email} to ${newEmail} without validation`);
  this.email = newEmail;
  this.isEmailVerified = false; // Reset verification status
  this.updatedAt = new Date();
};

// Method to increment session count for analytics
userSchema.methods.incrementSessionCount = function() {
  this.analytics.sessionCount += 1;
  this.analytics.lastLogin = new Date();
  this.updatedAt = new Date();
};

// Static method to find user by email (case insensitive)
userSchema.statics.findByEmail = function(email) {
  return this.findOne({ email: email.toLowerCase() });
};

// Virtual for full name (if we had firstName/lastName)
userSchema.virtual('displayName').get(function() {
  return this.username;
});

// Ensure virtual fields are serialized
userSchema.set('toJSON', {
  virtuals: true,
  transform: function(doc, ret) {
    delete ret.password;
    delete ret.emailVerificationToken;
    delete ret.__v;
    return ret;
  }
});

module.exports = mongoose.model('User', userSchema);
