const jwt = require('jsonwebtoken');

const auth = (req, res, next) => {
  try {
    // Try to get token from various sources
    let token = null;

    // 1. Authorization header (Bearer token)
    if (req.headers.authorization) {
      const authHeader = req.headers.authorization;
      if (authHeader.startsWith('Bearer ')) {
        token = authHeader.substring(7);
        console.log('🔐 Token found in Authorization header');
      }
    }

    // 2. Session cookie (fallback)
    if (!token && req.cookies?.session_token) {
      token = req.cookies.session_token;
      console.log('🔐 Token found in session cookie');
    }

    // 3. Query parameter (VULNERABILITY - for demo purposes)
    if (!token && req.query.token) {
      token = req.query.token;
      console.log('⚠️  VULNERABILITY: Token found in query parameter (insecure)');
    }

    if (!token) {
      return res.status(401).json({ 
        error: 'Access denied. No authentication token provided.',
        hint: 'Include token in Authorization header or login to set session cookie'
      });
    }

    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'weak_secret_key_for_demo_purposes');
    
    // Add user info to request
    req.user = {
      userId: decoded.userId,
      username: decoded.username
    };

    console.log(`✅ Authentication successful for user: ${decoded.username} (${decoded.userId})`);
    next();

  } catch (error) {
    console.error('Authentication error:', error.message);
    
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({ error: 'Invalid token' });
    }
    
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token expired' });
    }

    res.status(500).json({ error: 'Server error during authentication' });
  }
};

module.exports = auth;
